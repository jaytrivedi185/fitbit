import React from "react";
import styled from "styled-components";
import { Header } from "../header/header";
export const Banner = ({}) => {
  return (
    <>
    <Header/>
        <NewRootRoot>
      <Bg>
        <Group>
          <Group12>
            <WorldsFirstDiscountBrokingCryptoExchange>
              World's first discount broking crypto exchange.
            </WorldsFirstDiscountBrokingCryptoExchange>
            <FibitEnablesBuyOrSellBitcoinAndOtherCryptosInRealTime247WithOnlyMax1Or1FeesWhicheverIsLess>
              Fibit enables buy or sell Bitcoin and other cryptos in real time,
              24/7 with only max $1 or 0.1% fees whichever is less.
            </FibitEnablesBuyOrSellBitcoinAndOtherCryptosInRealTime247WithOnlyMax1Or1FeesWhicheverIsLess>
          </Group12>
          <Group5>
            <Border
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6e15d9a9-bb0d-430f-b58a-a9dace8e9a3e.svg?alt=media&token=f4dfe74b-098c-406f-b461-0093a9ab3c6f"
              }
            />
            <ViewExchange>View Exchange</ViewExchange>
          </Group5>
        </Group>
        <Image1
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/8f7dcbcd-6979-4682-b817-66c018f5f4a3.png?alt=media&token=1dfeb152-3b1d-426a-802f-f3d9feed5dfd"
          }
        />
      </Bg>
        </NewRootRoot>
    </>
    
  );
};
const NewRootRoot = styled.div`
  width: 1920px;
  height: 769px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg = styled.div`
  background-color: #00dbae;
  width: 1293px;
  display: flex;
  flex-direction: row;
  gap: 49px;
  padding-left: 375px;
  padding-right: 252px;
  padding-top: 60px;
  padding-bottom: 77px;
`;
const Group = styled.div`
  display: flex;
  flex-direction: column;
  gap: 50px;
  padding-top: 124px;
  padding-bottom: 107px;
  align-items: flex-start;
`;
const Group12 = styled.div`
  height: 296px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const WorldsFirstDiscountBrokingCryptoExchange = styled.div`
  color: #ffffff;
  width: 584px;
  height: 200px;
  font-size: 70px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -2.1px;
  line-height: 75px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const FibitEnablesBuyOrSellBitcoinAndOtherCryptosInRealTime247WithOnlyMax1Or1FeesWhicheverIsLess = styled.div`
  color: #ffffff;
  width: 514px;
  height: 46px;
  font-size: 20px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 32px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group5 = styled.div`
  width: 191px;
  height: 55px;
  position: relative;
`;
const Border = styled.img`
  width: 191px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const ViewExchange = styled.div`
  color: #14161b;
  text-align: center;
  width: 113px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 40px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const Image1 = styled.img`
  width: 660px;
  height: 632px;
`;
