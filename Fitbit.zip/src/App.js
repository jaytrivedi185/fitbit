import './App.css';
import {Header} from "./header/header";
import {Breadcum} from "./header/breadcum";
import {Section1} from "./section/section1";
import {Section2} from "./section/section2";
import {Section3} from "./section/section3";
import {Marketplace} from "./section/marketplace";
import {Product} from "./section/product";
import {Creators} from "./section/creators";
import {Releatedproducts} from "./section/releatedproduct";
import {Footer} from "./footer/footer";
import { Routes, Route, Link } from "react-router-dom";


function App() {
  return (
    <>
    <Routes>
        <Route path="/" element={<Home />} />
        <Route path="ProductPage" element={<ProductPage />} />
        <Route path="Marketplaces" element={<Marketplaces />} />
        <Route path="Creator" element={<Creator />} />
    </Routes>
    </>
  );
}

function Home() {
  return (
    <>
      <Section1 />
      <Section2 />
      <Section3 />
      <Footer />
      <nav>
        <Link to="/about">About</Link>
      </nav>
    </>
  );
}

function ProductPage() {
  return (
    <>
      <Header />
      <Breadcum />
      <Product />
      <Releatedproducts />
      <Footer />
      <nav>
        <Link to="/">Home</Link>
      </nav>
    </>
  );
}

function Marketplaces() {
  return (
    <>
      <Header />
      <Breadcum />
      <Marketplace />
      <Footer />
      <nav>
        <Link to="/">Home</Link>
      </nav>
    </>
  );
}


function Creator() {
  return (
    <>
      <Header />
      <Breadcum />
      <Creators />
      <Footer />
      <nav>
        <Link to="/">Home</Link>
      </nav>
    </>
  );
}

export default App;
