import React from "react";
import styled from "styled-components";
export const Header = ({}) => {
  return (
    <NewRootRoot>
      <Group7>
        {/* <Rectangle1
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c3633c0c-1b3a-435e-aab1-410b1e85df27.svg?alt=media&token=74db3153-20cf-40bb-ad29-0d00c4506047"
          }
        /> */}
        <Bg
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/d6101b52-eb45-46f9-8bca-c12fe2ce09eb.svg?alt=media&token=94f57209-7c8d-426d-a8ff-328d019c32be"
          }
        />
        <Btn>
          <Bg1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/d031ec1d-2acf-4d18-b1d4-df7e21735368.svg?alt=media&token=d0180287-c267-4460-b477-cc882dfb52a7"
            }
          />
          <RegisterNow>Register Now</RegisterNow>
        </Btn>
        <ExchangeMarkets>
          Creator &nbsp;&nbsp; Marketplace &nbsp;
        </ExchangeMarkets>
        <Bg2>
          <SearchHere>Search here</SearchHere>
          
        </Bg2>
        <Frame1
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c972a27c-ff3f-4bb0-ac0f-13da11bdd49a.svg?alt=media&token=a5934b46-477f-4e0b-9339-b571da80d14e"
          }
        />
        <Login>Login</Login>
        <Bg3>
          <SearchHere1>Search here</SearchHere1>
          <Vector
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/965c74f6-3aaf-4fe2-a38e-6256354e8b6e.svg?alt=media&token=0208c8b2-fbc4-41f6-bd0c-59b5fe6de7e9"
            }
          />
        </Bg3>
      </Group7>
    </NewRootRoot>
  );
};
const Vector = styled.img`
  width: 13.5px;
  height: 13.5px;
  align-self: stretch;
`;
const NewRootRoot = styled.div`
  width: 1920px;
  height: 115px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Group7 = styled.div`
  width: 1920px;
  height: 115px;
  position: relative;
`;
const Rectangle1 = styled.img`
  width: 1920px;
  height: 115px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Bg = styled.img`
  width: 205px;
  height: 55px;
  position: absolute;
  top: 31px;
  left: 1200px;
`;
const Btn = styled.div`
  width: 205px;
  height: 55px;
  position: absolute;
  top: 30px;
  left: 1418px;
`;
const Bg1 = styled.img`
  width: 205px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const RegisterNow = styled.div`
  color: #ffffff;
  width: 110px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 54px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const ExchangeMarkets = styled.div`
  color: #14161b;
  width: 203px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 51px;
  left: 740px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
const Bg2 = styled.div`
  background-color: #ffffff;
  border-width: 2px;
  border-color: rgba(20, 22, 27, 0.12);
  border-style: solid;
  width: 170px;
  position: absolute;
  top: 30px;
  left: 428px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-left: 25px;
  padding-right: 25px;
  padding-top: 21px;
  padding-bottom: 20.5px;
  align-items: flex-start;
  border-radius: 70px;
`;
const SearchHere = styled.div`
  color: #14161b;
  width: 85px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 27px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Frame1 = styled.img`
  width: 202px;
  height: 54px;
  position: absolute;
  top: 30px;
  left: 155px;
`;
const Login = styled.div`
  color: #ffffff;
  width: 110px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 51px;
  left: 1283px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Bg3 = styled.div`
  border-width: 2px;
  border-color: #ffffff;
  border-style: solid;
  width: 170px;
  position: absolute;
  top: 20px;
  left: 428px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-left: 25px;
  padding-right: 25px;
  padding-top: 21px;
  padding-bottom: 20.5px;
  align-items: flex-start;
  border-radius: 70px;
`;
const SearchHere1 = styled.div`
  color: #ffffff;
  width: 85px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 27px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
