import React from "react";
import styled from "styled-components";
export const Breadcum = ({}) => {
  return (
    <NewRootRoot>
      <Bg
        src={
          "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/83477fcb-d19f-4e37-b220-3d4c2d55b7ab.png?alt=media&token=db68acd2-363f-4810-9ce5-8f71e726d194"
        }
      />
      <Bg
        src={
          "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/3f7e3158-9239-4508-a364-c0965feef9cb.png?alt=media&token=31e798e0-6490-4fef-9196-f02c55783b1c"
        }
      />
      <ShopNow>Shop Now</ShopNow>
      <HomeShopNow>Home{"      "}Shop Now</HomeShopNow>
      <Vector
        src={
          "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/4a869920-0e66-47ca-b2bc-279be078f08d.svg?alt=media&token=94c634df-60d1-4567-9eb8-a7d844db2080"
        }
      />
    </NewRootRoot>
  );
};
const Bg = styled.img`
  width: 1920px;
  height: 220px;
  position: absolute;
  top: 0;
  left: 0;
`;
const NewRootRoot = styled.div`
  width: 1920px;
  height: 220px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  position: relative;
`;
const ShopNow = styled.div`
  color: #ffffff;
  width: 370px;
  height: 39px;
  font-size: 55px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -1.65px;
  line-height: 75px;
  position: absolute;
  top: 90px;
  left: 375px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const HomeShopNow = styled.div`
  color: #ffffff;
  width: 269px;
  height: 17px;
  font-size: 24px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 75px;
  position: absolute;
  top: 101px;
  left: 1278px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
const Vector = styled.img`
  width: 6px;
  height: 9.99px;
  position: absolute;
  top: 106px;
  left: 1357px;
`;
