import React from "react";
import styled from "styled-components";
export const Section1 = ({}) => {
  return (
    <NewRootRoot>
      <Component11 />
    </NewRootRoot>
  );
};
const Component11 = ({ className }) => {
  return (
    <Component1 className={className}>
      <Group>
        <Bg>
          <Group4>
            <Group12>
              <WorldsFirstDiscountBrokingCryptoExchange>
                World's first discount broking crypto exchange.
              </WorldsFirstDiscountBrokingCryptoExchange>
              <FibitEnablesBuyOrSellBitcoinAndOtherCryptosInRealTime247WithOnlyMax1Or1FeesWhicheverIsLess>
                Fibit enables buy or sell Bitcoin and other cryptos in real
                time, 24/7 with only max $1 or 0.1% fees whichever is less.
              </FibitEnablesBuyOrSellBitcoinAndOtherCryptosInRealTime247WithOnlyMax1Or1FeesWhicheverIsLess>
            </Group12>
            <Group5>
              <Border
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/0fe5d54b-3bcc-4325-b55b-c1616bacb674.svg?alt=media&token=deb4a78d-a35b-49eb-aa1c-24ee293a9cb2"
                }
              />
              <ViewExchange>View Exchange</ViewExchange>
            </Group5>
          </Group4>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/43a3d599-4b9c-4f65-b529-f3771a03d0f2.png?alt=media&token=fd6122ba-5e91-4aed-bd16-dfff1d9f6af8"
            }
          />
        </Bg>
        <Bg12>
          <SearchHere>Search here</SearchHere>
          <Vector
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/891912bf-cdf4-4785-aaf3-659fe63cbdfd.svg?alt=media&token=72b972ab-cba6-4082-a8c5-3d6963f2b0e2"
            }
          />
        </Bg12>
        <Group7>
          <Rectangle1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/d087c5ce-8a9e-4e4b-ac48-c9d98766c801.svg?alt=media&token=dbcefa91-2040-4722-a334-d0e78608b27c"
            }
          />
          <Bg13
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6a400372-9899-4e01-9ff4-40d4fee91670.svg?alt=media&token=4520ba54-c761-4c7d-930b-8ab1c37bf81c"
            }
          />
          <Btn>
            <Bg14
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/b6b5f288-c655-4536-a61f-0b443422e26b.svg?alt=media&token=efa70be1-2b8a-4965-8b06-ae9aaabebedc"
              }
            />
            <RegisterNow>Register Now</RegisterNow>
          </Btn>
          <ExchangeMarkets>
            Exchange{"            "}Markets{"            "}
          </ExchangeMarkets>
          <Bg15>
            <SearchHere1>Search here</SearchHere1>
            <Vector
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/7aa0f575-3500-4c1f-9f5e-c2b181e788fc.svg?alt=media&token=d3af1783-22e0-40ce-b972-ad4d625c2b1e"
              }
            />
          </Bg15>
          <Frame1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e660ceae-757b-496a-9f88-35de8802a1cf.svg?alt=media&token=119d713e-610f-4ad9-826b-2b6cde9dd772"
            }
          />
          <Login>Login</Login>
        </Group7>
      </Group>
      <Group1>
        <Title>
          <Group8>
            <Group9>
              <Ellipse5
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f3694269-eb61-4b25-8289-840e65e90b5f.svg?alt=media&token=40262a51-42ee-46e1-8a5b-939bda825c99"
                }
              />
              <Ellipse6
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/8ea3c6f2-fa95-4fb1-ba29-f3fbc426844b.svg?alt=media&token=6dd3c003-33d9-4c02-9512-6c138f613ed1"
                }
              />
            </Group9>
            <LiveAuctions>Live Auctions</LiveAuctions>
          </Group8>
          <SedUtPerspiciatisUndeAmnisNatusError>
            Sed ut perspiciatis unde amnis natus error
          </SedUtPerspiciatisUndeAmnisNatusError>
        </Title>
        <Navigation
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/48271285-b7f0-47ad-b1d0-26266c9ac736.svg?alt=media&token=ae6558d4-b0e1-45a8-99fe-e5e72326ecc9"
          }
        />
      </Group1>
      <Group3>
        <_1>
          <Bg1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/07e80d06-88d7-4fc4-8dd8-dd786e955a05.svg?alt=media&token=f549c55e-2cf5-43d0-9b58-1b60ebcdb485"
            }
          />
          <CurrentBid>Current Bid</CurrentBid>
          <_523ETH>5.23 ETH</_523ETH>
          <_32420>= $32.420</_32420>
          <LoremIpsumSetUtPerspiciatisUnde>
            Lorem Ipsum Set ut perspiciatis unde
          </LoremIpsumSetUtPerspiciatisUnde>
          <Image2
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e41f096e-8da6-4a41-bde6-54dc60fdf8df.png?alt=media&token=c74f0114-ddd6-4479-b5b8-d1c7f7a64277"
            }
          />
          <Timing>
            <Bg2
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2371e668-f0de-49a9-b044-153593f11d57.svg?alt=media&token=1d62344d-0ad4-425a-8dc0-062486ae22bd"
              }
            />
            <_5293248>05:29:32:48</_5293248>
          </Timing>
          <Creator1>
            <Image3
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/ba568321-66e1-4140-bf0b-95cf9ef65b68.png?alt=media&token=fc39c022-4eba-4da6-9d90-70bdbf4cf350"
              }
            />
            <Group11>
              <JaneDoe>Jane Doe</JaneDoe>
              <Creator>Creator</Creator>
            </Group11>
          </Creator1>
          <_6>
            <Bg1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/9c904e97-3419-428c-8105-675ef7be7894.svg?alt=media&token=f5683e02-c22d-4a36-aa16-02ecf06f45bb"
              }
            />
            <CurrentBid>Current Bid</CurrentBid>
            <_523ETH>5.23 ETH</_523ETH>
            <_32420>= $32.420</_32420>
            <LoremIpsumSetUtPerspiciatisUnde>
              Lorem Ipsum Set ut perspiciatis unde
            </LoremIpsumSetUtPerspiciatisUnde>
            <Image2
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/cc9f85aa-21ca-4dd2-9da9-9de8a55fe903.png?alt=media&token=ad158025-f1f8-4650-a2a9-4d4adcd10794"
              }
            />
            <Timing>
              <Bg2
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/dccdf83e-2194-4b73-b8f5-3175d844af4e.svg?alt=media&token=1005efc9-cef6-4a4a-a037-5cdb3eece3bd"
                }
              />
              <_5293248>05:29:32:48</_5293248>
            </Timing>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/7f7efc35-6ee8-4215-a275-887f535932b4.png?alt=media&token=79d2cbd6-aa09-4cbb-9fe6-d9ae76f2f7f5"
                }
              />
              <Group11>
                <JaneDoe>Jane Doe</JaneDoe>
                <Creator>Creator</Creator>
              </Group11>
            </Creator1>
            <Bg1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/172e1b21-5138-4208-88ff-a83a6a1707f1.svg?alt=media&token=7bebf8a6-15ac-4973-8c54-f010ec62b993"
              }
            />
          </_6>
        </_1>
        <Group10>
          <CurrentBid2>Current Bid</CurrentBid2>
          <_523ETH2>5.23 ETH</_523ETH2>
          <_324202>= $32.420</_324202>
          <LoremIpsumSetUtPerspiciatisUnde2>
            Lorem Ipsum Set ut perspiciatis unde
          </LoremIpsumSetUtPerspiciatisUnde2>
          <Image9>
            <Bg6
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/cb27bda6-75c5-4c1f-a017-e9fe20c6188f.svg?alt=media&token=895aaf7d-7afa-4d37-a214-3ca64cd1a328"
              }
            />
            <Image8
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/d3eba7c0-ffa9-4962-bb7f-bea855bc07b0.png?alt=media&token=2085a187-e298-4435-b865-1c2300899cca"
              }
            />
            <Image8
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6d067df6-2f29-4dd9-ac10-091ed68b075c.png?alt=media&token=34cbd941-3b33-42c9-b6a2-d434d3365147"
              }
            />
          </Image9>
          <Timing2>
            <Bg2
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e8ab94df-747d-419c-8109-c6313b54a5d8.svg?alt=media&token=c80f235e-f2e4-4b90-8714-59c8e34cb718"
              }
            />
            <_5293248>05:29:32:48</_5293248>
          </Timing2>
          <Creator5>
            <Image3
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/bf7d6410-515b-4e23-a8d3-5c1b7d67d592.png?alt=media&token=bd1919bf-5b4a-4310-8b24-0911f7250842"
              }
            />
            <Group11>
              <JaneDoe>John Doe</JaneDoe>
              <Creator>Creator</Creator>
            </Group11>
          </Creator5>
          <Bg16 />
        </Group10>
        <Bg8>
          <Group15>
            <Image14
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/80614990-c7bb-411e-b0bd-7029339c47f0.png?alt=media&token=229a3ce7-cb5c-49f5-a3b5-dccf416a7000"
              }
            />
            <Timing3>
              <Bg2
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/45a4824e-c1cc-44f8-9aa2-8d5c11dc8464.svg?alt=media&token=c2c6b776-fbc1-4a7f-977f-730213bc9bf0"
                }
              />
              <_5293248>05:29:32:48</_5293248>
            </Timing3>
          </Group15>
          <LoremIpsumSetUtPerspiciatisUnde3>
            Lorem Ipsum Set ut perspiciatis unde
          </LoremIpsumSetUtPerspiciatisUnde3>
          <Image16
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6ef5ebc2-c3c5-4e9e-9209-8190e0871b2e.png?alt=media&token=e2d17428-1025-4a42-8b49-02df4985736c"
            }
          />
          <CurrentBid3>Current Bid</CurrentBid3>
          <Group16>
            <_523ETH3>5.23 ETH</_523ETH3>
            <_324203>= $32.420</_324203>
          </Group16>
        </Bg8>
        <Bg10>
          <Group17>
            <Image18
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f2dd6bc8-5542-4aa9-b9e0-8aaaa3b2b2f8.png?alt=media&token=6471de59-d1a3-4611-adf2-d952db82dd97"
              }
            />
            <Timing3>
              <Bg2
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/a1426ab5-445f-4af4-9aad-ccaf98243db3.svg?alt=media&token=7acee52a-741e-43a1-aa22-f5ec59be0e07"
                }
              />
              <_5293248>05:29:32:48</_5293248>
            </Timing3>
          </Group17>
          <LoremIpsumSetUtPerspiciatisUnde3>
            Lorem Ipsum Set ut perspiciatis unde
          </LoremIpsumSetUtPerspiciatisUnde3>
          <Creator7>
            <Image3
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6a42ab55-980a-4808-b1db-0dd8590953b2.png?alt=media&token=1a6ddf28-59ed-48cb-93b6-87f31a63b402"
              }
            />
            <Group11>
              <JaneDoe>John Doe</JaneDoe>
              <Creator>Creator</Creator>
            </Group11>
          </Creator7>
          <CurrentBid3>Current Bid</CurrentBid3>
          <Group16>
            <_523ETH3>5.23 ETH</_523ETH3>
            <_324203>= $32.420</_324203>
          </Group16>
        </Bg10>
      </Group3>
      <Pagination
        src={
          "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2d3e0418-a968-4325-86eb-35741547a8db.svg?alt=media&token=bb803d1e-25a2-423f-8ba8-77761f76eee8"
        }
      />
    </Component1>
  );
};
const Component1 = styled.div`
  height: 1682px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Group = styled.div`
  height: 874px;
  margin-bottom: 102px;
  width: 1920px;
  position: relative;
`;
const Bg = styled.div`
  background-color: #00dbae;
  width: 1293px;
  position: absolute;
  top: 105px;
  left: 0;
  display: flex;
  flex-direction: row;
  gap: 49px;
  padding-left: 375px;
  padding-right: 252px;
  padding-top: 60px;
  padding-bottom: 77px;
`;
const Group4 = styled.div`
  display: flex;
  flex-direction: column;
  gap: 50px;
  padding-top: 124px;
  padding-bottom: 107px;
  align-items: flex-start;
`;
const Group12 = styled.div`
  height: 296px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const WorldsFirstDiscountBrokingCryptoExchange = styled.div`
  color: #ffffff;
  width: 584px;
  height: 200px;
  font-size: 70px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -2.1px;
  line-height: 75px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const FibitEnablesBuyOrSellBitcoinAndOtherCryptosInRealTime247WithOnlyMax1Or1FeesWhicheverIsLess = styled.div`
  color: #ffffff;
  width: 514px;
  height: 46px;
  font-size: 20px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 32px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group5 = styled.div`
  width: 191px;
  height: 55px;
  position: relative;
`;
const Border = styled.img`
  width: 191px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const ViewExchange = styled.div`
  color: #14161b;
  text-align: center;
  width: 113px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 40px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const Image1 = styled.img`
  width: 660px;
  height: 632px;
`;
const Bg12 = styled.div`
  border-width: 2px;
  border-color: #ffffff;
  border-style: solid;
  width: 170px;
  position: absolute;
  top: 20px;
  left: 428px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-left: 25px;
  padding-right: 25px;
  padding-top: 21px;
  padding-bottom: 20.5px;
  align-items: flex-start;
  border-radius: 70px;
`;
const SearchHere = styled.div`
  color: #ffffff;
  width: 85px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 27px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group7 = styled.div`
  width: 1920px;
  height: 115px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Rectangle1 = styled.img`
  width: 1920px;
  height: 115px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Bg13 = styled.img`
  width: 205px;
  height: 55px;
  position: absolute;
  top: 31px;
  left: 1200px;
`;
const Btn = styled.div`
  width: 205px;
  height: 55px;
  position: absolute;
  top: 30px;
  left: 1418px;
`;
const Bg14 = styled.img`
  width: 205px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const RegisterNow = styled.div`
  color: #ffffff;
  width: 110px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 54px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const ExchangeMarkets = styled.div`
  color: #14161b;
  width: 203px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 51px;
  left: 740px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
const Bg15 = styled.div`
  background-color: #ffffff;
  border-width: 2px;
  border-color: rgba(20, 22, 27, 0.12);
  border-style: solid;
  width: 170px;
  position: absolute;
  top: 30px;
  left: 428px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-left: 25px;
  padding-right: 25px;
  padding-top: 21px;
  padding-bottom: 20.5px;
  align-items: flex-start;
  border-radius: 70px;
`;
const SearchHere1 = styled.div`
  color: #14161b;
  width: 85px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 27px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Frame1 = styled.img`
  width: 202px;
  height: 54px;
  position: absolute;
  top: 30px;
  left: 155px;
`;
const Login = styled.div`
  color: #ffffff;
  width: 110px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 51px;
  left: 1283px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group1 = styled.div`
  margin-bottom: 60px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-left: 376px;
  padding-right: 376px;
  align-items: flex-end;
`;
const Title = styled.div`
  height: 66px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-end;
`;
const Group8 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 13px;
`;
const Group9 = styled.div`
  width: 26px;
  height: 29px;
  position: relative;
`;
const Ellipse5 = styled.img`
  width: 26px;
  height: 26px;
  position: absolute;
  top: 2px;
  left: 0;
`;
const Ellipse6 = styled.img`
  width: 12px;
  height: 12px;
  position: absolute;
  top: 9px;
  left: 7px;
`;
const LiveAuctions = styled.div`
  color: #14161b;
  width: 253px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeAmnisNatusError = styled.div`
  color: #14161b;
  width: 358px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Navigation = styled.img`
  width: 120px;
  height: 55px;
`;
const Group3 = styled.div`
  margin-bottom: 60px;
  display: flex;
  flex-direction: row;
  justify-content: center;
`;
const _1 = styled.div`
  width: 270px;
  height: 500px;
  margin-right: 28px;
  position: relative;
`;
const _6 = styled.div`
  width: 270px;
  height: 500px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Group10 = styled.div`
  width: 270px;
  margin-right: 32px;
  height: 500px;
  position: relative;
`;
const CurrentBid2 = styled.div`
  color: #7d7d7d;
  width: 74px;
  height: 10px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 428px;
  left: 37px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _523ETH2 = styled.div`
  color: #14161b;
  width: 72px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 448px;
  left: 37px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _324202 = styled.div`
  color: #7d7d7d;
  width: 65px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 449px;
  left: 106px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const LoremIpsumSetUtPerspiciatisUnde2 = styled.div`
  color: #14161b;
  width: 185px;
  height: 34px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 309px;
  left: 37px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Image9 = styled.div`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 49px;
  left: 27px;
`;
const Bg6 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Timing2 = styled.div`
  width: 178px;
  height: 38px;
  position: absolute;
  top: 30px;
  left: 48px;
`;
const Creator5 = styled.div`
  width: 154px;
  position: absolute;
  top: 363px;
  left: 37px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Bg16 = styled.div`
  background-color: rgba(99, 69, 237, 0.07);
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  width: 270px;
  height: 500px;
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 20px;
`;
const Bg8 = styled.div`
  background-color: rgba(99, 69, 237, 0.07);
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  height: 430px;
  margin-right: 30px;
  display: flex;
  flex-direction: column;
  padding-top: 30px;
  padding-bottom: 40px;
  padding-left: 25px;
  padding-right: 25px;
  align-items: flex-start;
  border-radius: 20px;
`;
const Group15 = styled.div`
  align-self: stretch;
  height: 249px;
  margin-bottom: 30px;
  width: 220px;
  position: relative;
`;
const Image14 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 19px;
  left: 0;
  border-radius: 20px;
`;
const Image16 = styled.img`
  width: 40px;
  height: 40px;
  margin-left: 10px;
  margin-bottom: 25px;
  border-radius: 20px;
`;
const Bg10 = styled.div`
  background-color: rgba(99, 69, 237, 0.07);
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  height: 428px;
  display: flex;
  flex-direction: column;
  padding-top: 32px;
  padding-bottom: 40px;
  padding-left: 25px;
  padding-right: 25px;
  align-items: flex-start;
  border-radius: 20px;
`;
const Group17 = styled.div`
  align-self: stretch;
  height: 247px;
  margin-bottom: 30px;
  width: 220px;
  position: relative;
`;
const Image18 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 17px;
  left: 0;
  border-radius: 20px;
`;
const Creator7 = styled.div`
  width: 154px;
  margin-left: 10px;
  margin-bottom: 25px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Pagination = styled.img`
  width: 71px;
  height: 20px;
  align-self: center;
`;
const Vector = styled.img`
  width: 13.5px;
  height: 13.5px;
  align-self: stretch;
`;
const Bg1 = styled.img`
  width: 270px;
  height: 500px;
  position: absolute;
  top: 0;
  left: 0;
`;
const CurrentBid = styled.div`
  color: #7d7d7d;
  width: 74px;
  height: 10px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 428px;
  left: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _523ETH = styled.div`
  color: #14161b;
  width: 72px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 448px;
  left: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _32420 = styled.div`
  color: #7d7d7d;
  width: 65px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 449px;
  left: 104px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const LoremIpsumSetUtPerspiciatisUnde = styled.div`
  color: #14161b;
  width: 185px;
  height: 34px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 309px;
  left: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Image2 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 49px;
  left: 25px;
  border-radius: 20px;
`;
const Timing = styled.div`
  width: 178px;
  height: 38px;
  position: absolute;
  top: 30px;
  left: 46px;
`;
const Bg2 = styled.img`
  width: 178px;
  height: 38px;
  position: absolute;
  top: 0;
  left: 0;
`;
const _5293248 = styled.div`
  color: #ffffff;
  width: 128px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 600;
  letter-spacing: 3.6px;
  line-height: 30px;
  position: absolute;
  top: 13px;
  left: 25px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator1 = styled.div`
  width: 154px;
  position: absolute;
  top: 363px;
  left: 35px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Image3 = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 20px;
`;
const Group11 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 5px;
  padding-bottom: 5px;
  align-items: flex-start;
`;
const JaneDoe = styled.div`
  color: #14161b;
  width: 104px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -0.45px;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator = styled.div`
  color: #959595;
  width: 52px;
  height: 10px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 22px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Image8 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 20px;
`;
const Timing3 = styled.div`
  width: 178px;
  height: 38px;
  position: absolute;
  top: 0;
  left: 21px;
`;
const LoremIpsumSetUtPerspiciatisUnde3 = styled.div`
  color: #14161b;
  width: 185px;
  height: 34px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  margin-left: 10px;
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const CurrentBid3 = styled.div`
  color: #7d7d7d;
  width: 74px;
  height: 10px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  margin-left: 10px;
  margin-bottom: 10px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group16 = styled.div`
  align-self: stretch;
  height: 12px;
  width: 220px;
  position: relative;
`;
const _523ETH3 = styled.div`
  color: #14161b;
  width: 72px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 0;
  left: 10px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _324203 = styled.div`
  color: #7d7d7d;
  width: 65px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 1px;
  left: 79px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const NewRootRoot = styled.div`
  height: 1682px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin: auto;
  min-width: 1920px;
`;
