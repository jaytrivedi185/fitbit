import React from "react";
import styled from "styled-components";
export const Section2 = ({}) => {
  return (
    <NewRootRoot>
      <Bg3 />
      <Bg6>
        <Group>
          <Title>
            <BestSellers>Best Sellers</BestSellers>
            <SedUtPerspiciatisUndeAmnisNatusError>
              Sed ut perspiciatis unde amnis natus error
            </SedUtPerspiciatisUndeAmnisNatusError>
          </Title>
          <Group2>
            <_1>
              <Border
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/d15e4a73-f0d8-49c6-abde-2b6f76633dcd.svg?alt=media&token=fdf3cec8-757d-40ab-8135-0df2a6f71de0"
                }
              />
              <Btn>
                <Bg7
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/52518e8b-3ae7-4dbb-a3b3-502f52f15f23.svg?alt=media&token=d0c371d8-5c2a-4676-b082-f9d90e2da02a"
                  }
                />
                <Follow>Follow</Follow>
              </Btn>
              <Image1
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/ec037a69-8f09-4c7a-8055-91eb79b653cc.png?alt=media&token=4ccd718c-d0de-4552-99be-aae6feac7102"
                }
              />
              <JasonMStalls>Jason M. Stalls</JasonMStalls>
              <_5237ETH>523.7 ETH</_5237ETH>
            </_1>
            <Border1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/0eef690d-f0f1-4686-90eb-d4d07bc1e045.png?alt=media&token=3618c731-6506-47f9-8959-5789699908d0"
                }
              />
              <FrankFChan>Frank F. Chan</FrankFChan>
              <_5237ETH1>523.7 ETH</_5237ETH1>
              <Btn1>
                <Bg7
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/95af3dea-c14f-4bd3-bfe7-eb2e96f8f5b6.svg?alt=media&token=748df684-4121-42ca-9120-8ad1cf3d3216"
                  }
                />
                <Follow1>Follow</Follow1>
              </Btn1>
            </Border1>
          </Group2>
        </Group>
        <Border2>
          <Image3
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/a90a82b3-8f5b-463f-a826-408876fd6a9c.png?alt=media&token=a193fc7f-6a9b-47ba-9c62-5a1797e16be5"
            }
          />
          <RobertGeorge>Robert George</RobertGeorge>
          <_5237ETH1>523.7 ETH</_5237ETH1>
          <Btn1>
            <Bg7
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/9a6bfe90-ee62-4d7c-85cb-c79219bfa570.svg?alt=media&token=e3a3ec19-e4e8-432a-98fc-9167309d290f"
              }
            />
            <Follow1>Follow</Follow1>
          </Btn1>
        </Border2>
        <Border2>
          <Image9>
            <Image7
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/8868d90a-3f26-494d-ab34-90e7be649fe2.png?alt=media&token=23113862-81fc-42a0-bb00-d3859e7a9dc0"
              }
            />
            <Image7
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f0a5fabc-a861-496c-812b-5673da48d686.png?alt=media&token=5f8f2e1e-997e-4d6a-bc0a-9d602248c8e8"
              }
            />
          </Image9>
          <FrankNGlisson>
            Frank N. Glisson
            <br />
          </FrankNGlisson>
          <_5237ETH1>523.7 ETH</_5237ETH1>
          <Btn1>
            <Bg7
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/d2154d09-abe2-4fc4-9a47-fbb7f87340cf.svg?alt=media&token=af3d98f8-b893-4b44-bbb0-6449aeb1ac04"
              }
            />
            <Follow1>Follow</Follow1>
          </Btn1>
        </Border2>
        <Border4>
          <Image9>
            <Image7
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2faf9b9f-1a82-4b14-bb36-42ea0d1e1620.png?alt=media&token=4c49e3b7-f137-483e-8adb-4cf00078f7e5"
              }
            />
            <Image7
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/237bde79-f82e-42fd-8fe6-30bf5aa934a3.png?alt=media&token=78312a32-adac-47ec-9659-3d60f245c667"
              }
            />
          </Image9>
          <MichelZonaS>Michel ZonaS</MichelZonaS>
          <_5237ETH1>523.7 ETH</_5237ETH1>
          <Btn1>
            <Bg7
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/adb55ee7-800c-4c70-a458-7197e65f8d4a.svg?alt=media&token=39f472d2-32d6-408f-94d5-7e0fbb77e212"
              }
            />
            <Follow1>Follow</Follow1>
          </Btn1>
        </Border4>
        <Group1>
          <Btn7>
            <Bg13
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f19c8966-f98d-43cc-906e-32e5908ad549.svg?alt=media&token=9d868cd9-4261-4359-9fd3-b357bd2e26fc"
              }
            />
            <ExploreMore>Explore More</ExploreMore>
            <Btn6>
              <Bg13
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/1f2aa679-f48a-46bc-a567-2f890417e1fe.svg?alt=media&token=0df9ef36-6a44-43b2-b2ed-519d1b7bbad4"
                }
              />
              <ExploreMore1>Explore More</ExploreMore1>
              <_></_>
            </Btn6>
          </Btn7>
          <Border5>
            <Image9>
              <Image7
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/99ce50e5-96d6-442a-a726-3f4271c6e21e.png?alt=media&token=a7919d7d-51f3-4f70-a9eb-3a5c1c5f4a1f"
                }
              />
              <Image16>
                <Image7
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2b8e0796-e19c-4b1e-94a6-54d5a836cec1.png?alt=media&token=dccf721d-7c48-44e4-989f-41323b430ffc"
                  }
                />
                <Image7
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/3c4d3523-cbd8-4c4a-8d4e-e7bb459a6f37.png?alt=media&token=11840530-6ac8-47b6-8462-4484a0a820da"
                  }
                />
              </Image16>
            </Image9>
            <MizanurMango>Mizanur Mango</MizanurMango>
            <_5237ETH1>523.7 ETH</_5237ETH1>
            <Btn1>
              <Bg7
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/eb7cff03-244c-40e6-b0ac-f3f540265d7c.svg?alt=media&token=cc7622d7-8d7c-40c2-ba44-30e1c9e66edb"
                }
              />
              <Follow1>Follow</Follow1>
            </Btn1>
          </Border5>
        </Group1>
      </Bg6>
    </NewRootRoot>
  );
};
const Bg2 = ({ className }) => {
  return (
    <Bg1 className={className}>
      <Bg />
    </Bg1>
  );
};
const Bg1 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg = styled.div`
  background-color: #fdfdfd;
  width: 1920px;
  height: 804px;
`;
const Bg7 = styled.img`
  width: 80px;
  height: 28px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Image3 = styled.img`
  width: 115px;
  height: 115px;
  margin-bottom: 20px;
  align-self: stretch;
  border-radius: 60px;
`;
const _5237ETH1 = styled.div`
  color: #616161;
  width: 57px;
  height: 9px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 16px;
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Btn1 = styled.div`
  width: 80px;
  height: 28px;
  position: relative;
`;
const Follow1 = styled.div`
  color: #14161b;
  width: 40px;
  height: 10px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  position: absolute;
  top: 9px;
  left: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Border2 = styled.div`
  border-width: 2px;
  border-color: rgba(99, 69, 237, 0.1);
  border-style: solid;
  height: 276px;
  margin-right: 30px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 28px;
  padding-right: 27px;
  align-items: center;
  border-radius: 12px;
`;
const Image9 = styled.div`
  width: 115px;
  height: 115px;
  margin-bottom: 20px;
  align-self: stretch;
  position: relative;
`;
const Image7 = styled.img`
  width: 115px;
  height: 115px;
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 60px;
`;
const Bg13 = styled.img`
  width: 191px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const NewRootRoot = styled.div`
  height: 804px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  position: relative;
  margin: auto;
  min-width: 1920px;
`;
const Bg3 = styled(Bg2)`
  position: absolute;
`;
const Bg6 = styled.div`
  background-color: #ffffff;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.19);
  width: 1172px;
  position: absolute;
  top: 162px;
  left: 244px;
  display: flex;
  flex-direction: row;
  padding-left: 88px;
  padding-right: 90px;
  padding-top: 60px;
  padding-bottom: 60px;
  align-items: flex-end;
  border-radius: 30px;
`;
const Group = styled.div`
  align-self: stretch;
  margin-right: 30px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const Title = styled.div`
  height: 66px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const BestSellers = styled.div`
  color: #14161b;
  width: 216px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeAmnisNatusError = styled.div`
  color: #14161b;
  width: 358px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  gap: 30px;
`;
const _1 = styled.div`
  width: 170px;
  height: 276px;
  position: relative;
`;
const Border = styled.img`
  width: 170px;
  height: 276px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Btn = styled.div`
  width: 80px;
  height: 28px;
  position: absolute;
  top: 218px;
  left: 44px;
`;
const Follow = styled.div`
  color: #ffffff;
  width: 40px;
  height: 10px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  position: absolute;
  top: 9px;
  left: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Image1 = styled.img`
  width: 115px;
  height: 115px;
  position: absolute;
  top: 30px;
  left: 27px;
  border-radius: 60px;
`;
const JasonMStalls = styled.div`
  color: #14161b;
  width: 108px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  position: absolute;
  top: 165px;
  left: 30px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _5237ETH = styled.div`
  color: #616161;
  width: 57px;
  height: 9px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 16px;
  position: absolute;
  top: 189px;
  left: 56px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Border1 = styled.div`
  border-width: 2px;
  border-color: rgba(99, 69, 237, 0.1);
  border-style: solid;
  height: 276px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 27px;
  padding-right: 28px;
  align-items: center;
  border-radius: 12px;
`;
const FrankFChan = styled.div`
  color: #14161b;
  width: 97px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  margin-bottom: 12px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const RobertGeorge = styled.div`
  color: #14161b;
  width: 106px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  margin-bottom: 12px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const FrankNGlisson = styled.div`
  color: #14161b;
  width: 114px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 0;
  margin-bottom: 12px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Border4 = styled.div`
  border-width: 2px;
  border-color: rgba(99, 69, 237, 0.1);
  border-style: solid;
  height: 276px;
  margin-right: 9px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 27px;
  padding-right: 28px;
  align-items: center;
  border-radius: 12px;
`;
const MichelZonaS = styled.div`
  color: #14161b;
  width: 100px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  margin-bottom: 12px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  gap: 40px;
  align-items: flex-end;
`;
const Btn7 = styled.div`
  width: 191px;
  height: 55px;
  align-self: stretch;
  position: relative;
`;
const ExploreMore = styled.div`
  color: #ffffff;
  width: 96px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 22px;
  left: 48px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Btn6 = styled.div`
  width: 191px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const ExploreMore1 = styled.div`
  color: #ffffff;
  width: 96px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 60px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _ = styled.div`
  color: #ffffff;
  width: 16px;
  height: 13px;
  font-size: 16px;
  font-family: Font Awesome 5 Pro;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Border5 = styled.div`
  border-width: 2px;
  border-color: rgba(99, 69, 237, 0.1);
  border-style: solid;
  height: 276px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 28px;
  padding-right: 27px;
  align-items: center;
  border-radius: 12px;
`;
const Image16 = styled.div`
  width: 115px;
  height: 115px;
  position: absolute;
  top: 0;
  left: 0;
`;
const MizanurMango = styled.div`
  color: #14161b;
  width: 115px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  margin-bottom: 12px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
