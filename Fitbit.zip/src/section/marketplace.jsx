import React from "react";
import styled from "styled-components";
export const Marketplace   = ({}) => {
  return (
    <NewRootRoot>
      <Bg3 />
      <Popular>
        <Group>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/37b2ff8f-9441-4603-a61c-3445e4e2baeb.png?alt=media&token=beeaf40a-8e00-49ee-a45e-f5cda7c940d4"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/25560196-99d0-4259-86b8-2ca58e827307.png?alt=media&token=0bc6e3c4-ea63-45b6-90ec-679a6f11ebd6"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/cb0561a9-6f95-461d-accf-e0604536fc6e.png?alt=media&token=c3bcccfa-045f-4623-a580-cf9bf8ad3916"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/761bfc96-c879-4511-96d0-1ce8276143d6.png?alt=media&token=0dbb52ea-4da1-4f25-a87e-d31c07559122"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/dc191594-d1ac-40de-98f6-35ff5d03b6eb.png?alt=media&token=8cd661f6-8a92-4ea9-b2be-4518fc6e1802"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2e6008d4-a064-4150-8d0b-fa540d1a3a32.png?alt=media&token=e9f880f8-8fcb-4f3a-83aa-5595a371bd1c"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/673c7273-125b-4505-826a-b7eabb437531.png?alt=media&token=4063fe1c-e218-4f8f-8a4f-00860a5d9d5b"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/a609397b-1f88-4bfb-87b4-48a67fb37d91.png?alt=media&token=584fe5d9-0c64-465c-9ca8-7c1209cd446c"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
        </Group>
        <Group>
          <Bg6>
            <Group7>
              <Image5
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/5eae6cfc-2577-42fe-9e7b-b0dac3d8f629.png?alt=media&token=ce0a41b5-8c54-4999-bff5-a8617e1b1e5e"
                }
              />
              <Avatar>
                <Image11
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/23d395ae-82bc-41e8-8f03-f4a3c2a3733d.png?alt=media&token=d9081792-0b54-466a-9af0-d6c30f4d3e1f"
                  }
                />
                <Image41
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/9e2c3e9a-a29f-499d-b056-7ece42f2d8fb.png?alt=media&token=776f5c6e-56a5-49f7-b734-8a635c80f6de"
                  }
                />
                <Image51
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/46c71eed-2179-4113-9814-121768673701.png?alt=media&token=25da7f45-7f2a-47af-9056-53d4baa50069"
                  }
                />
                <Image31
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/63485088-5212-4c56-ae0e-710010d9913d.png?alt=media&token=499a07e0-f287-4d05-98c3-be902c9554e5"
                  }
                />
              </Avatar>
              
            </Group7>
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/17c51506-cd5b-4eb8-95a3-bdacfefa4b9e.png?alt=media&token=94cd398a-dedd-41d0-945c-1bd4f67f7547"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6c66552e-95b8-418b-97e6-87d91a1f9606.png?alt=media&token=672ecffc-772e-448e-9041-257ae97981a7"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f0e7d0f9-6c4a-448d-a9a1-603054875b72.png?alt=media&token=5df50074-0daf-4b42-a99c-30ff2a9198b5"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/7e13e4f2-c4d4-4bcc-ae43-0228d84ba60e.png?alt=media&token=95ef939e-4493-4aac-9489-cf375986e33c"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/64833864-f498-4128-934d-e818586510d1.png?alt=media&token=b2f31b6e-86e0-4ee1-b508-3e1fd8f6c101"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2e323e8b-d5e4-48fa-a582-51f2bc3c6c6d.png?alt=media&token=6500970d-e34a-433c-b819-71a11a55f0e3"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/dde15c4e-84b6-413d-a688-c904c7e046d8.png?alt=media&token=e6fe6dd8-92ce-4913-80c8-0fab1f3a2d9a"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
        </Group>
        <Group2>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/abe417b7-c954-4e7c-b8b5-9c5e9d900371.png?alt=media&token=21acdbb5-2380-4162-88cc-0f5ba1e2a7d1"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/28fbe910-4dd0-4e55-9e40-1513f8393526.png?alt=media&token=dac27feb-aa7d-490f-ab78-a4e8d318e984"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/3aee7d9e-89e9-47bb-9b39-e7c2e8e71917.png?alt=media&token=f0f61dfd-25f8-471d-a096-715d5039b428"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/06b38b6c-7e82-40d5-8a35-ed4c959f5f17.png?alt=media&token=d9383b0d-8c6c-49c8-8ae3-56c135eb7385"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/108a6bc1-164c-404a-98cf-98115bbede11.png?alt=media&token=20fef3b3-ce44-4b37-9103-edf6d1f2c163"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/0df23a8e-a170-4448-bf37-05cd048821d1.png?alt=media&token=e299d2fe-63f8-4443-a03f-09292fa617b9"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
          <Bg6>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/fc8392aa-f29c-4b58-8516-d8ae52e60da5.png?alt=media&token=9c30a433-4ecb-4c15-8e30-6b0eb17c5865"
              }
            />
            <_3DSpaceRocketWithSmokePremium>
              ‘’3D Space Rocket With <br />
              Smoke Premium’’
            </_3DSpaceRocketWithSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/23146348-f7ce-48a8-bcf5-3fa771f85fac.png?alt=media&token=cbc76cfc-1241-469f-896d-4ef18267d86f"
                }
              />
              <Group3>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group3>
            </Creator1>
          </Bg6>
        </Group2>
        <Btn>
          <Bg19
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/5fa71522-ce3b-4791-b80e-bc8fb4ce8940.svg?alt=media&token=cf4e0317-53f7-447e-8d9b-0dcd28e620c2"
            }
          />
          <ExploreNow>Explore Now</ExploreNow>
          <_></_>
        </Btn>
      </Popular>
      <Bg20>
        <Border>
          <AllCategories>All Categories</AllCategories>
          <Vector
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/37fcb50e-8afe-4079-9047-7d28d896dab4.svg?alt=media&token=41064c6b-7d38-4b50-99ad-d19d2d71cc31"
            }
          />
        </Border>
        <Border>
          <NewIteams>New Iteams</NewIteams>
          <Vector
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/b21d4169-70fa-4db4-899f-8468b64cf698.svg?alt=media&token=c0ed9125-d327-4b93-972a-ba21db0e5b15"
            }
          />
        </Border>
        <Border>
          <AllCategories>Buy Now</AllCategories>
          <Vector
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e9db8859-5b92-4241-b848-f6580a030a13.svg?alt=media&token=9d5c2630-ee64-49b2-ac5e-54b6831cc92f"
            }
          />
        </Border>
        <Border>
          <SortBy>Sort By</SortBy>
          <Vector
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c39694ca-050f-4a17-aed0-9b7f24c9310e.svg?alt=media&token=4a2cb5bb-7b6d-4dd9-a327-7f45c01d0b11"
            }
          />
        </Border>
        <Btn1>
          <Bg19
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/185d637f-85e8-4322-86b1-82a641703e1c.svg?alt=media&token=57cb701e-dd15-4dde-bc36-7ea5866510cb"
            }
          />
          <Filter>Filter</Filter>
          <_14></_14>
        </Btn1>
      </Bg20>
    </NewRootRoot>
  );
};
const Bg2 = ({ className }) => {
  return (
    <Bg1 className={className}>
      <Bg />
    </Bg1>
  );
};
const Bg1 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg = styled.div`
  background-color: #ffffff;
  width: 1920px;
  height: 1835px;
`;
const Group = styled.div`
  margin-bottom: 30px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Bg6 = styled.div`
  background-color: rgba(99, 69, 237, 0.07);
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  height: 416px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 25px;
  padding-right: 25px;
  align-items: flex-start;
  border-radius: 20px;
`;
const Image1 = styled.img`
  width: 220px;
  height: 230px;
  margin-bottom: 42px;
  align-self: stretch;
  border-radius: 20px;
`;
const _3DSpaceRocketWithSmokePremium = styled.div`
  color: #14161b;
  width: 185px;
  height: 34px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  margin-left: 10px;
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator1 = styled.div`
  width: 154px;
  margin-left: 10px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Image3 = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 20px;
`;
const Group3 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 5px;
  padding-bottom: 5px;
  align-items: flex-start;
`;
const DanielMBivens = styled.div`
  color: #6345ed;
  width: 104px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -0.45px;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator = styled.div`
  color: #959595;
  width: 52px;
  height: 10px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 22px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Bg19 = styled.img`
  width: 205px;
  height: 50px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Border = styled.div`
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.1);
  border-style: solid;
  width: 165px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  border-radius: 30px;
  padding: 20px;
`;
const AllCategories = styled.div`
  width: 88px;
  height: 10px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Vector = styled.img`
  width: 10.01px;
  height: 6.01px;
`;
const NewRootRoot = styled.div`
  width: 1920px;
  height: 1835px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  position: relative;
`;
const Bg3 = styled(Bg2)`
  position: absolute;
`;
const Popular = styled.div`
  height: 1418px;
  position: absolute;
  top: 374px;
  left: 416px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Group7 = styled.div`
  align-self: stretch;
  height: 247px;
  margin-bottom: 25px;
  width: 220px;
  position: relative;
`;
const Image5 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 20px;
`;
const Avatar = styled.div`
  width: 80px;
  height: 35px;
  position: absolute;
  top: 212px;
  left: 16px;
`;
const Image11 = styled.img`
  width: 35px;
  height: 35px;
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 18px;
`;
const Image41 = styled.img`
  width: 35px;
  height: 35px;
  position: absolute;
  top: 0;
  left: 15px;
  border-radius: 18px;
`;
const Image51 = styled.img`
  width: 35px;
  height: 35px;
  position: absolute;
  top: 0;
  left: 30px;
  border-radius: 18px;
`;
const Image31 = styled.img`
  width: 35px;
  height: 35px;
  position: absolute;
  top: 0;
  left: 45px;
  border-radius: 18px;
`;
const Tag = styled.div`
  width: 47px;
  height: 20px;
  position: absolute;
  top: 220px;
  left: 148px;
`;
const Bg8 = styled.img`
  width: 47px;
  height: 20px;
  position: absolute;
  top: 0;
  left: 0;
`;
const RUN = styled.div`
  color: #ffffff;
  width: 27px;
  height: 9px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 22px;
  position: absolute;
  top: 6px;
  left: 10px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group2 = styled.div`
  margin-bottom: 60px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Btn = styled.div`
  width: 205px;
  height: 50px;
  margin-right: 479px;
  align-self: flex-end;
  position: relative;
`;
const ExploreNow = styled.div`
  color: #ffffff;
  width: 110px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 18px;
  left: 66px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _ = styled.div`
  color: #ffffff;
  width: 14px;
  height: 13px;
  font-size: 16px;
  font-family: Font Awesome 5 Brands;
  font-weight: 400;
  line-height: 18px;
  position: absolute;
  top: 17px;
  left: 34px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Bg20 = styled.div`
  background-color: #ffffff;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.15);
  width: 1105px;
  position: absolute;
  top: 204px;
  left: 416px;
  display: flex;
  flex-direction: row;
  gap: 20px;
  padding-left: 30px;
  padding-right: 35px;
  padding-top: 30px;
  padding-bottom: 30px;
  border-radius: 7px;
`;
const NewIteams = styled.div`
  width: 77px;
  height: 10px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SortBy = styled.div`
  width: 52px;
  height: 10px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Btn1 = styled.div`
  width: 205px;
  height: 50px;
  position: relative;
`;
const Filter = styled.div`
  color: #ffffff;
  width: 36px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 18px;
  left: 95px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _14 = styled.div`
  color: #ffffff;
  width: 14px;
  height: 13px;
  font-size: 16px;
  font-family: Font Awesome 5 Brands;
  font-weight: 400;
  line-height: 18px;
  position: absolute;
  top: 18px;
  left: 74px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
