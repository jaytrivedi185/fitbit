import React from "react";
import styled from "styled-components";
export const Cardv2 = ({}) => {
  return (
    <__1Root>
      <Bg>
        <Image1
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/b0610cbf-fe7f-42c2-83a1-01d9320b8a08.png?alt=media&token=5b1eb6bf-051a-429b-bd8c-4e53d50b2e3f"
          }
        />
        <LoremIpsum>Lorem Ipsum</LoremIpsum>
        <Creator1>
          <Image3
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/715f8a83-7f60-417e-9e62-8a8ad797252d.png?alt=media&token=d3f90d81-e464-4c18-832b-dce3e94143fa"
            }
          />
          <Group>
            <JaneDoe>Jane Doe</JaneDoe>
            <Creator>Creator</Creator>
          </Group>
        </Creator1>
        <Bg1 />
      </Bg>
    </__1Root>
  );
};
const __1Root = styled.div`
  width: 370px;
  height: 480px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg = styled.div`
  background-color: #ffffff;
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  height: 480px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  border-radius: 20px;
`;
const Image1 = styled.img`
  width: 370px;
  height: 275px;
  margin-bottom: 40px;
  align-self: stretch;
  border-radius: 20px;
`;
const LoremIpsum = styled.div`
  color: #14161b;
  width: 254px;
  height: 13px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  margin-left: 40px;
  margin-bottom: 25px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator1 = styled.div`
  width: 154px;
  margin-left: 40px;
  margin-bottom: 35px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Image3 = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 20px;
`;
const Group = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 5px;
  padding-bottom: 5px;
  align-items: flex-start;
`;
const JaneDoe = styled.div`
  color: #14161b;
  width: 104px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -0.45px;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator = styled.div`
  color: #959595;
  width: 52px;
  height: 10px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 22px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Bg1 = styled.div`
  background-color: #00dbae;
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  width: 370px;
  height: 52px;
  align-self: stretch;
`;
