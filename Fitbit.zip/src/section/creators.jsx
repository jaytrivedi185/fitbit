import React from "react";
import styled from "styled-components";
export const Creators = ({}) => {
  return <Group21 />;
};
const Bg6 = ({ className }) => {
  return (
    <Bg2 className={className}>
      <Bg />
    </Bg2>
  );
};
const Group21 = ({ className }) => {
  return (
    <Group2 className={className}>
      <Bg7 />
      <_1>
        <Group>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/26ae62a5-1df0-4179-a12d-db3565a7a09a.png?alt=media&token=1b47bb3d-4ce5-4d2c-b5d2-9cd0e7dc1198"
            }
          />
          <Bg301
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/a85eecd3-3abb-4b1a-9968-8a15e44e9833.png?alt=media&token=5e57d0cb-7c8a-4675-80dc-7985a9063ed8"
            }
          />
        </Group>
        <JohnSOutenewes>John S. Outenewes</JohnSOutenewes>
        <Group1>
          <Bg11 />
          <ERC83>ERC - 83</ERC83>
        </Group1>
      </_1>
      <_5>
        <Group>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c3aa3344-5be2-4f42-ba4b-62f0be64643f.png?alt=media&token=f8aff2b9-efbc-4a7b-8d47-fceed4bd63ac"
            }
          />
          <Bg301
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c93bfe74-4b31-419c-a149-85001ed0fbf7.png?alt=media&token=eb46ce19-8d25-4e04-b720-aa872cfe37fd"
            }
          />
        </Group>
        <JohnSOutenewes>David Mich Hussy</JohnSOutenewes>
        <Group1>
          <Bg11 />
          <ERC83>ERC - 83</ERC83>
        </Group1>
      </_5>
      <_2>
        <Group>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/72406bc7-d8c4-4938-b56e-2ff6e1a5c3c3.png?alt=media&token=27095990-5d9a-4305-9d3a-68d0d5ddd72b"
            }
          />
          <Image4
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/4b09fdb2-e5d2-4731-a173-7283b5b2d8ad.png?alt=media&token=8cc3b4f1-2b9d-4ed5-aca2-6de88ae0a1d3"
            }
          />
          <Bg301
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/560055a6-4522-4d38-b377-fe8367be0e23.png?alt=media&token=68fca241-20ae-4a2a-9cb3-657e4e118282"
            }
          />
        </Group>
        <MichelDokniaKalia>Michel Doknia Kalia</MichelDokniaKalia>
        <Group1>
          <Bg11 />
          <ERC83>ERC - 83</ERC83>
        </Group1>
      </_2>
      <_6>
        <Group>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/782b6a34-0fad-4fd7-bb1d-c19927262347.png?alt=media&token=ae349667-757e-4bbf-a6d4-93da77f6e374"
            }
          />
          <Bg301
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/9eaaf1c9-1fe9-48d1-abcf-a517750eef83.png?alt=media&token=205ce855-1829-4669-9ee4-7a3cb4b84cdf"
            }
          />
        </Group>
        <JohnSOutenewes>John S. Outenewes</JohnSOutenewes>
        <Group1>
          <Bg11 />
          <ERC83>ERC - 83</ERC83>
        </Group1>
      </_6>
      <_3>
        <Group>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/4a6bfa0c-7c8e-462d-8e1a-9171d4219558.png?alt=media&token=065a93fe-520e-4aff-a313-2803f911baa3"
            }
          />
          <Bg301
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/41cf01b6-2be8-4257-9470-272549680807.png?alt=media&token=a8b7c918-7e9d-4f60-aafc-97eab7657e28"
            }
          />
        </Group>
        <JohnSOutenewes>Somalia X Silva</JohnSOutenewes>
        <Group1>
          <Bg11 />
          <ERC83>ERC - 83</ERC83>
        </Group1>
      </_3>
      <_7>
        <Group>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6f6f4b55-0f59-4cca-9768-bc4af5d580e0.png?alt=media&token=72db4621-5b34-4119-93d0-8d9e79ea6381"
            }
          />
          <Bg301
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/74ff50d2-1a38-40be-a3bd-d5c3ddbd6f73.png?alt=media&token=8093c65e-1e41-4208-b152-9b00e905c997"
            }
          />
        </Group>
        <JohnSOutenewes>Zavi HD. Xossy</JohnSOutenewes>
        <Group1>
          <Bg11 />
          <ERC83>ERC - 83</ERC83>
        </Group1>
      </_7>
      <_4>
        <Group>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/a6948117-f2b4-4f84-a985-bdb53e018c63.png?alt=media&token=128f572b-eccb-46b4-96c9-3a778623bf75"
            }
          />
          <Bg301
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/cbc58cf7-1f18-44d8-a2b0-bccf0248f9a3.png?alt=media&token=9df44db4-352c-40d3-9502-3054552fa2e8"
            }
          />
        </Group>
        <JohnSOutenewes>Medas S Alskae</JohnSOutenewes>
        <Group1>
          <Bg11 />
          <ERC83>ERC - 83</ERC83>
        </Group1>
      </_4>
      <_8>
        <Group>
          <Image9
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/4bfd1af3-91a2-4068-9781-76ee85e11492.png?alt=media&token=acfaf0bd-98c6-46d7-b82c-a6366f7e1476"
            }
          />
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/a2f221db-f761-4245-8514-2b5153f650d9.png?alt=media&token=a8369aab-b7ee-4ca8-8d7a-14a7c93e0aec"
            }
          />
          <Bg301
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6cd88e7b-b4ba-48f6-84ba-196c861de6bb.png?alt=media&token=72d4acc7-c67c-4f5a-b972-a4a693a19252"
            }
          />
        </Group>
        <JohnSOutenewes>Fillips H Hearts</JohnSOutenewes>
        <Group1>
          <Bg11 />
          <ERC83>ERC - 83</ERC83>
        </Group1>
      </_8>
      <Title>
        <HotCollection>Hot Collection</HotCollection>
        <MostPopularGamingDigitalNftMarketPlace>
          Most popular gaming digital nft market place{" "}
        </MostPopularGamingDigitalNftMarketPlace>
      </Title>
      <Navigation
        src={
          "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/475fa5e6-ddea-4d44-8e7b-98e115043021.svg?alt=media&token=3ad040dd-92a9-411e-8e53-7c6bccf6e309"
        }
      />
    </Group2>
  );
};
const Bg2 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg = styled.div`
  background-color: rgba(99, 69, 237, 0.05);
  width: 1920px;
  height: 892px;
`;
const Group2 = styled.div`
  width: 1920px;
  height: 892px;
  position: relative;
`;
const Bg7 = styled(Bg6)`
  position: absolute;
`;
const _1 = styled.div`
  width: 270px;
  height: 296px;
  position: absolute;
  top: 195px;
  left: 375px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const _5 = styled.div`
  height: 296px;
  position: absolute;
  top: 521px;
  left: 375px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const _2 = styled.div`
  height: 296px;
  position: absolute;
  top: 195px;
  left: 675px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const Image4 = styled.img`
  width: 80px;
  height: 80px;
  position: absolute;
  top: 130px;
  left: 96px;
`;
const MichelDokniaKalia = styled.div`
  color: #14161b;
  text-align: center;
  width: 161px;
  height: 13px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  margin-right: 51px;
  margin-bottom: 13px;
  align-self: flex-end;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const _6 = styled.div`
  height: 296px;
  position: absolute;
  top: 521px;
  left: 675px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const _3 = styled.div`
  height: 296px;
  position: absolute;
  top: 195px;
  left: 975px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const _7 = styled.div`
  height: 296px;
  position: absolute;
  top: 521px;
  left: 975px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const _4 = styled.div`
  height: 296px;
  position: absolute;
  top: 195px;
  left: 1275px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const _8 = styled.div`
  height: 296px;
  position: absolute;
  top: 521px;
  left: 1275px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const Image9 = styled.img`
  background-color: #c4c4c4;
  border-top-left-radius: 7px;
  border-top-right-radius: 7px;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  width: 270px;
  height: 170px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Title = styled.div`
  height: 66px;
  position: absolute;
  top: 87px;
  left: 377px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const HotCollection = styled.div`
  color: #14161b;
  width: 262px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const MostPopularGamingDigitalNftMarketPlace = styled.div`
  color: #14161b;
  width: 358px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
const Navigation = styled.img`
  width: 120px;
  height: 55px;
  position: absolute;
  top: 98px;
  left: 1422px;
`;
const Group = styled.div`
  height: 210px;
  margin-bottom: 20px;
  width: 270px;
  position: relative;
`;
const Image1 = styled.img`
  border-top-left-radius: 7px;
  border-top-right-radius: 7px;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  width: 270px;
  height: 170px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Bg301 = styled.img`
  width: 80px;
  height: 80px;
  position: absolute;
  top: 130px;
  left: 96px;
  border-radius: 40px;
`;
const JohnSOutenewes = styled.div`
  color: #14161b;
  text-align: center;
  width: 155px;
  height: 13px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  margin-bottom: 13px;
  align-self: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const Group1 = styled.div`
  height: 10px;
  width: 270px;
  position: relative;
`;
const Bg11 = styled.div`
  background-color: rgba(99, 69, 237, 0.07);
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  border-top-left-radius: 7px;
  border-top-right-radius: 7px;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  width: 270px;
  height: 127px;
  transform-origin: 0px 0px;
  transform: rotate(180deg);
  position: absolute;
  top: 40px;
  left: 270px;
`;
const ERC83 = styled.div`
  color: #616161;
  text-align: center;
  width: 49px;
  height: 10px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 18px;
  position: absolute;
  top: 0;
  left: 111px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
