import React from "react";
import styled from "styled-components";
export const Product = ({}) => {
  return (
    <NewRootRoot>
      <Bg9>
        <Component22 />
        <Btn2 />
        <Tab>
          <_17>
            <Bg19
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f457c5ac-f6b2-4cc2-96c1-4387b9822e7c.svg?alt=media&token=bf3d5671-9f7a-4947-83bf-9e9fde7742c7"
              }
            />
            <Bids>Bids</Bids>
          </_17>
          <_24>
            <Bg20
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/ec2a041d-8641-4b67-ad75-6a073018322a.svg?alt=media&token=b91e7376-2cde-4088-9dbc-120ecb994e55"
              }
            />
            <History1>History</History1>
          </_24>
          <_34>
            <Bg21
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e3cea3c0-c9bd-47f7-adbf-a3d576c07a8d.svg?alt=media&token=81a66322-3439-407e-b2b7-96743a101a13"
              }
            />
            <Details>Details</Details>
          </_34>
        </Tab>
        <_18>
          <Image13
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/5b4f5026-54a0-4034-bbec-818574584f38.png?alt=media&token=aa120ea3-8ad6-4335-80c8-a0af37a7bff8"
            }
          />
          <BidListedFor25ETH8HoursAgoByJohnson6>
            Bid listed for
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson1>
              25 ETH
            </BidListedFor25ETH8HoursAgoByJohnson1>
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
              8
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson3>
              {" "}
              hours ago
              <br />
              by
            </BidListedFor25ETH8HoursAgoByJohnson3>
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson5>
              @Johnson
            </BidListedFor25ETH8HoursAgoByJohnson5>
          </BidListedFor25ETH8HoursAgoByJohnson6>
        </_18>
        <_18>
          <Image13
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/dc998c44-3a33-4dba-9415-358f3211f9bb.png?alt=media&token=f8f12100-9edb-4b27-a99c-ba14f9a7db74"
            }
          />
          <BidListedFor25ETH8HoursAgoByJohnson6>
            Bid listed for
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson1>
              25 ETH
            </BidListedFor25ETH8HoursAgoByJohnson1>
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
              8
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson3>
              {" "}
              hours ago
              <br />
              by
            </BidListedFor25ETH8HoursAgoByJohnson3>
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson5>
              @Johnson
            </BidListedFor25ETH8HoursAgoByJohnson5>
          </BidListedFor25ETH8HoursAgoByJohnson6>
        </_18>
        <_35>
          <Image13
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c641bd6d-9b1b-4d92-a4af-16ca14ec2ece.png?alt=media&token=f9d95672-ccf4-4efc-9685-bd220a120be9"
            }
          />
          <BidListedFor25ETH8HoursAgoByJohnson6>
            Bid listed for
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson1>
              25 ETH
            </BidListedFor25ETH8HoursAgoByJohnson1>
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
              8
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson3>
              {" "}
              hours ago
              <br />
              by
            </BidListedFor25ETH8HoursAgoByJohnson3>
            <BidListedFor25ETH8HoursAgoByJohnson>
              {" "}
            </BidListedFor25ETH8HoursAgoByJohnson>
            <BidListedFor25ETH8HoursAgoByJohnson5>
              @Johnson
            </BidListedFor25ETH8HoursAgoByJohnson5>
          </BidListedFor25ETH8HoursAgoByJohnson6>
        </_35>
      </Bg9>
    </NewRootRoot>
  );
};
const Component21 = ({ className }) => {
  return (
    <Component2 className={className}>
      <Group>
        <Image231
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/4f8c78e4-7302-4f19-bdef-e324b4ccdc53.png?alt=media&token=116bed90-f74c-4c9d-a284-ceb4b642473c"
          }
        />
        <Bg>
          <Bg1>
            <_25Days1>
              25
              <br />
              <_25Days>Days</_25Days>
            </_25Days1>
          </Bg1>
          <Bg1>
            <_25Days1>
              38
              <br />
              <_25Days>Hour</_25Days>
            </_25Days1>
          </Bg1>
          <Bg1>
            <_25Days1>
              49
              <br />
              <_25Days>Mint</_25Days>
            </_25Days1>
          </Bg1>
          <Bg1>
            <_25Days1>
              54
              <br />
              <_25Days>Seco</_25Days>
            </_25Days1>
          </Bg1>
        </Bg>
      </Group>
      <Group1>
        <MissionForGhostFighter>
          Mission For Ghost
        </MissionForGhostFighter>
        <SedUtPerspiciatisUndeOmnisIsteNatusErrorSitVoluptatemAccusantiumDoloremqueLaudantiumTotamRemAperiamEaqueIpsaQuaeAbIlloInventoreVeritatisEtQuasiArchitectoBeataeVitaeDictaSuntExplicaboNemoEnimIpsamVoluptatemQuiaVoluptasSitAspernaturAut>
          Sed ut perspiciatis unde omnis iste natus error sit voluptatem
          accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae
          ab illo inventore veritatis et quasi architecto beatae vitae dicta
          sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit
          aspernatur aut
        </SedUtPerspiciatisUndeOmnisIsteNatusErrorSitVoluptatemAccusantiumDoloremqueLaudantiumTotamRemAperiamEaqueIpsaQuaeAbIlloInventoreVeritatisEtQuasiArchitectoBeataeVitaeDictaSuntExplicaboNemoEnimIpsamVoluptatemQuiaVoluptasSitAspernaturAut>
        <Group2>
          <Image2
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e1a589f0-6957-40ac-a050-a9b6b978e355.png?alt=media&token=3d7ebbf2-069e-46d0-9631-042663199763"
            }
          />
          <Group1>
            <OwnerBy>Owner By</OwnerBy>
            <JohnDoe>John Doe</JohnDoe>
            <Social>
              <_></_>
              <_5></_5>
              <_6></_6>
              <_7></_7>
            </Social>
          </Group1>
        </Group2>
        <CurrentPrice15ETH500891Of5Size14000X14000PxVolumeTraded641>
          Current Price 1.5 ETH
          {"             "}$500.89
          {"                              "}1 of 5<br />
          Size 14000 x 14000 px
          <br />
          Volume Traded 64.1
        </CurrentPrice15ETH500891Of5Size14000X14000PxVolumeTraded641>
        <Group3>
          <Bg5>
            <Image4
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/ca1a7065-f001-4914-8255-25125a205e33.png?alt=media&token=1a9c5189-529c-4f65-a635-9478cf91153a"
              }
            />
            <Group5>
              <JohnDoe1>John Doe</JohnDoe1>
              <Creators>Creators</Creators>
            </Group5>
          </Bg5>
          <Bg5>
            <Image4
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/d5238cd7-7e2d-4acc-b6af-bd07ee80102f.png?alt=media&token=a09c3519-b6cb-4daa-ba92-f5529941208e"
              }
            />
            <Group5>
              <JohnDoe2>John Doe</JohnDoe2>
              <Collection>Collection</Collection>
            </Group5>
          </Bg5>
        </Group3>
        <Bg7>
          <CurrentPrice>Current Price</CurrentPrice>
          <Collection>9.3 BNB</Collection>
        </Bg7>
      </Group1>
    </Component2>
  );
};
const Btn1 = ({ className }) => {
  return (
    <Btn className={className}>
      <Bg8
        src={
          "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/dfba3184-995f-450c-840f-e5c5a3062f70.svg?alt=media&token=b9be6848-179c-42c3-8e96-01c3a7c318ac"
        }
      />
      <BuyNow>Buy Now!</BuyNow>
      <_8></_8>
    </Btn>
  );
};
const Component2 = styled.div`
  width: 1170px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Group = styled.div`
  width: 570px;
  height: 644px;
  position: relative;
`;
const Image231 = styled.img`
  width: 570px;
  height: 516px;
  position: absolute;
  top: 50px;
  left: 0;
  border-radius: 12px;
`;
const Bg = styled.div`
  background-color: #02a886;
  width: 355px;
  position: absolute;
  top: 0;
  left: 103px;
  display: flex;
  flex-direction: row;
  padding-top: 15px;
  padding-bottom: 15px;
  border-radius: 7px;
`;
const MissionForGhostFighter = styled.div`
  color: #14161b;
  width: 339px;
  height: 21px;
  font-size: 30px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 75px;
  margin-bottom: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeOmnisIsteNatusErrorSitVoluptatemAccusantiumDoloremqueLaudantiumTotamRemAperiamEaqueIpsaQuaeAbIlloInventoreVeritatisEtQuasiArchitectoBeataeVitaeDictaSuntExplicaboNemoEnimIpsamVoluptatemQuiaVoluptasSitAspernaturAut = styled.div`
  color: #616161;
  width: 520px;
  height: 96px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 28px;
  margin-bottom: 50px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group2 = styled.div`
  align-self: stretch;
  margin-bottom: 50px;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 20px;
`;
const Image2 = styled.img`
  width: 70px;
  height: 70px;
  border-radius: 35px;
`;
const OwnerBy = styled.div`
  color: #616161;
  width: 65px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 28px;
  margin-bottom: 10px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const JohnDoe = styled.div`
  color: #14161b;
  width: 141px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 28px;
  margin-bottom: 15px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Social = styled.div`
  width: 93px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`;
const _ = styled.div`
  color: #00dbae;
  width: 9px;
  height: 15px;
  font-size: 14px;
  font-family: Font Awesome 5 Brands;
  font-weight: 400;
  line-height: 27px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _5 = styled.div`
  color: #979797;
  width: 14px;
  height: 15px;
  font-size: 14px;
  font-family: Font Awesome 5 Brands;
  font-weight: 400;
  line-height: 27px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _6 = styled.div`
  color: #979797;
  width: 12px;
  height: 13px;
  font-size: 14px;
  font-family: Font Awesome 5 Brands;
  font-weight: 400;
  line-height: 27px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _7 = styled.div`
  color: #979797;
  width: 13px;
  height: 12px;
  font-size: 14px;
  font-family: Font Awesome 5 Brands;
  font-weight: 400;
  line-height: 27px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const CurrentPrice15ETH500891Of5Size14000X14000PxVolumeTraded641 = styled.div`
  color: #616161;
  width: 407px;
  height: 80px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 35px;
  margin-bottom: 50px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
const Group3 = styled.div`
  align-self: stretch;
  margin-bottom: 30px;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 30px;
  padding-left: 3px;
  padding-right: 3px;
`;
const JohnDoe1 = styled.div`
  color: #14161b;
  width: 97px;
  height: 11px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 27px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creators = styled.div`
  color: #616161;
  width: 50px;
  height: 9px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 27px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const JohnDoe2 = styled.div`
  color: #14161b;
  width: 102px;
  height: 11px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 27px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Bg7 = styled.div`
  background-color: #ffffff;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.15);
  height: 32px;
  margin-left: 2px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 20px;
  padding-bottom: 20px;
  padding-left: 30px;
  padding-right: 333px;
  align-items: flex-start;
  border-radius: 8px;
`;
const CurrentPrice = styled.div`
  color: #14161b;
  width: 138px;
  height: 16px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 27px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Btn = styled.div`
  width: 240px;
  height: 55px;
  position: relative;
`;
const Bg8 = styled.img`
  width: 240px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const BuyNow = styled.div`
  color: #ffffff;
  width: 68px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 99px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _8 = styled.div`
  color: #ffffff;
  width: 16px;
  height: 13px;
  font-size: 16px;
  font-family: Font Awesome 5 Pro;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 74px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _18 = styled.div`
  width: 269px;
  margin-right: 248px;
  margin-bottom: 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`;
const Image13 = styled.img`
  width: 50px;
  height: 50px;
  align-self: stretch;
  border-radius: 25px;
`;
const BidListedFor25ETH8HoursAgoByJohnson6 = styled.div`
  color: #616161;
  width: 199px;
  height: 29px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 21px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const BidListedFor25ETH8HoursAgoByJohnson = styled.div`
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 21px;
  display: contents;
  white-space: pre-wrap;
`;
const BidListedFor25ETH8HoursAgoByJohnson1 = styled.div`
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 21px;
  display: contents;
`;
const BidListedFor25ETH8HoursAgoByJohnson3 = styled.div`
  font-size: 14px;
  color: #616161;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 21px;
  display: contents;
  white-space: pre-wrap;
`;
const BidListedFor25ETH8HoursAgoByJohnson5 = styled.div`
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 21px;
  display: contents;
`;
const Bg1 = styled.div`
  background-color: #ffffff;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.15);
  width: 70px;
  display: flex;
  flex-direction: row;
  justify-content: center;
  padding-top: 18px;
  padding-bottom: 19px;
  border-radius: 7px;
`;
const _25Days1 = styled.div`
  text-align: center;
  width: 31px;
  height: 33px;
  font-size: 27px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 21px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const _25Days = styled.div`
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 21px;
  display: contents;
`;
const Group1 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
`;
const Bg5 = styled.div`
  background-color: #ffffff;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.15);
  width: 195px;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 13px;
  padding-left: 20px;
  padding-right: 20px;
  padding-top: 15px;
  padding-bottom: 15px;
  border-radius: 8px;
`;
const Image4 = styled.img`
  width: 67px;
  height: 60px;
  border-radius: 35px;
`;
const Group5 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 14px;
  padding-bottom: 14px;
  align-items: flex-start;
`;
const Collection = styled.div`
  color: #616161;
  width: 56px;
  height: 9px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 27px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const NewRootRoot = styled.div`
  width: 1920px;
  height: 1190px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg9 = styled.div`
  background-color: rgba(99, 69, 237, 0.05);
  height: 1068px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding-top: 61px;
  padding-bottom: 61px;
  padding-left: 375px;
  padding-right: 375px;
  align-items: flex-end;
`;
const Component22 = styled(Component21)`
  margin-bottom: 30px;
  align-self: stretch;
`;
const Btn2 = styled(Btn1)`
  margin-right: 277px;
  margin-bottom: 50px;
`;
const Tab = styled.div`
  width: 255px;
  height: 30px;
  margin-right: 262px;
  margin-bottom: 30px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const _17 = styled.div`
  width: 67px;
  height: 30px;
  position: relative;
`;
const Bg19 = styled.img`
  width: 67px;
  height: 30px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Bids = styled.div`
  color: #ffffff;
  width: 38px;
  height: 9px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 10px;
  left: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _24 = styled.div`
  width: 85px;
  height: 30px;
  position: relative;
`;
const Bg20 = styled.img`
  width: 85px;
  height: 30px;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.3);
  position: absolute;
  top: 0;
  left: 0;
`;
const History1 = styled.div`
  color: #14161b;
  width: 45px;
  height: 9px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 10px;
  left: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _34 = styled.div`
  width: 83px;
  height: 30px;
  position: relative;
`;
const Bg21 = styled.img`
  width: 83px;
  height: 30px;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.3);
  position: absolute;
  top: 0;
  left: 0;
`;
const Details = styled.div`
  color: #14161b;
  width: 43px;
  height: 9px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 10px;
  left: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _35 = styled.div`
  width: 269px;
  margin-right: 248px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`;
