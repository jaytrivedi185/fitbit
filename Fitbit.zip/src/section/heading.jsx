import React from "react";
import styled from "styled-components";
export const Heading = ({}) => {
  return (
    <TitleRoot>
      <Group>
        <Group1>
          <Ellipse5
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/61be2d99-b198-467b-b68f-a1f45d4e76a3.svg?alt=media&token=78ec8c37-3cb4-4e06-b060-a00aa841e0c6"
            }
          />
          <Ellipse6
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/7dbb5a04-ed08-4750-8d81-82c5f6646fa1.svg?alt=media&token=089eb1cf-7ec6-4f80-8e63-d04976c450dd"
            }
          />
        </Group1>
        <LiveAuctions>Live Auctions</LiveAuctions>
      </Group>
      <SedUtPerspiciatisUndeAmnisNatusError>
        Sed ut perspiciatis unde amnis natus error
      </SedUtPerspiciatisUndeAmnisNatusError>
    </TitleRoot>
  );
};
const TitleRoot = styled.div`
  width: 397px;
  height: 66px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-end;
`;
const Group = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 13px;
`;
const Group1 = styled.div`
  width: 26px;
  height: 29px;
  position: relative;
`;
const Ellipse5 = styled.img`
  width: 26px;
  height: 26px;
  position: absolute;
  top: 2px;
  left: 0;
`;
const Ellipse6 = styled.img`
  width: 12px;
  height: 12px;
  position: absolute;
  top: 9px;
  left: 7px;
`;
const LiveAuctions = styled.div`
  color: #14161b;
  width: 253px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeAmnisNatusError = styled.div`
  color: #14161b;
  width: 358px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
