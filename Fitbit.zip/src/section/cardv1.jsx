import React from "react";
import styled from "styled-components";
export const Cardv1 = ({}) => {
  return (
    <NewRootRoot>
      <Bg
        src={
          "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/ff549c34-78c6-4c16-9ac4-d8543bb52276.svg?alt=media&token=cdb6f681-aac6-48f9-969b-bb686c586cee"
        }
      />
      <_1>
        <Bg
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/0aca331a-f4b8-47a4-a8f0-10c84343bf4a.svg?alt=media&token=847bbf78-48ea-4c73-8c09-b4952fce98b7"
          }
        />
        <CurrentBid>Current Bid</CurrentBid>
        <_523ETH>5.23 ETH</_523ETH>
        <_32420>= $32.420</_32420>
        <LoremIpsumSetUtPerspiciatisUnde>
          Lorem Ipsum Set ut perspiciatis unde
        </LoremIpsumSetUtPerspiciatisUnde>
        <Image1
          src={
            "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/190d388f-1ae2-47fb-9abd-1a5a175d44b4.png?alt=media&token=1ef38805-e1df-4b1f-9874-e9582f225f1f"
          }
        />
        <Timing>
          <Bg2
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/80db66da-4853-43ca-a2db-36c0d247cb85.svg?alt=media&token=0bbefc90-51e0-4146-8fda-661e16e76fda"
            }
          />
          <_5293248>05:29:32:48</_5293248>
        </Timing>
        <Creator1>
          <Image2
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/1f08e8ce-2c50-4bdb-9f93-1d9900815636.png?alt=media&token=1f752eeb-422a-4289-bb65-3f6b368b3889"
            }
          />
          <Group>
            <JaneDoe>Jane Doe</JaneDoe>
            <Creator>Creator</Creator>
          </Group>
        </Creator1>
        <_1>
          <Bg
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/0c6f5a3b-b4df-45b8-b31f-e88fc1113174.svg?alt=media&token=f8406262-794a-47b6-a0cc-ce0037d516da"
            }
          />
          <CurrentBid>Current Bid</CurrentBid>
          <_523ETH>5.23 ETH</_523ETH>
          <_32420>= $32.420</_32420>
          <LoremIpsumSetUtPerspiciatisUnde>
            Lorem Ipsum Set ut perspiciatis unde
          </LoremIpsumSetUtPerspiciatisUnde>
          <Image1
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/81336e12-0715-413c-9531-76787e2ed61f.png?alt=media&token=cade7d5e-87c3-406d-81d1-55b1b5a1b900"
            }
          />
          <Timing>
            <Bg2
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/1b3f62a5-421e-49ad-8258-3454ac1b3a92.svg?alt=media&token=56549506-ce0b-4bb2-9cd6-e88f7b819e4a"
              }
            />
            <_5293248>05:29:32:48</_5293248>
          </Timing>
          <Creator1>
            <Image2
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/5eb8f228-5363-4fed-942d-62db8d9e963b.png?alt=media&token=a7fde3e0-4f89-4f0d-9a1f-d87f26b65ed8"
              }
            />
            <Group>
              <JaneDoe>Jane Doe</JaneDoe>
              <Creator>Creator</Creator>
            </Group>
          </Creator1>
        </_1>
      </_1>
    </NewRootRoot>
  );
};
const Bg = styled.img`
  width: 270px;
  height: 500px;
  position: absolute;
  top: 0;
  left: 0;
`;
const _1 = styled.div`
  width: 270px;
  height: 500px;
  position: absolute;
  top: 0;
  left: 0;
`;
const CurrentBid = styled.div`
  color: #7d7d7d;
  width: 74px;
  height: 10px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 428px;
  left: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _523ETH = styled.div`
  color: #14161b;
  width: 72px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 448px;
  left: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _32420 = styled.div`
  color: #7d7d7d;
  width: 65px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 449px;
  left: 104px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const LoremIpsumSetUtPerspiciatisUnde = styled.div`
  color: #14161b;
  width: 185px;
  height: 34px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 309px;
  left: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Image1 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 49px;
  left: 25px;
  border-radius: 20px;
`;
const Timing = styled.div`
  width: 178px;
  height: 38px;
  position: absolute;
  top: 30px;
  left: 46px;
`;
const Bg2 = styled.img`
  width: 178px;
  height: 38px;
  position: absolute;
  top: 0;
  left: 0;
`;
const _5293248 = styled.div`
  color: #ffffff;
  width: 128px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 600;
  letter-spacing: 3.6px;
  line-height: 30px;
  position: absolute;
  top: 13px;
  left: 25px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator1 = styled.div`
  width: 154px;
  position: absolute;
  top: 363px;
  left: 35px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Image2 = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 20px;
`;
const Group = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 5px;
  padding-bottom: 5px;
  align-items: flex-start;
`;
const JaneDoe = styled.div`
  color: #14161b;
  width: 104px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -0.45px;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator = styled.div`
  color: #959595;
  width: 52px;
  height: 10px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 22px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const NewRootRoot = styled.div`
  width: 270px;
  height: 500px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  position: relative;
`;
