import React from "react";
import styled from "styled-components";
export const Section3 = ({}) => {
  return (
    <NewRootRoot>
      <Bg>
        <Trendy>
          <Group>
            <Title>
              <TrendyCollection>Trendy Collection</TrendyCollection>
              <SedUtPerspiciatisUndeOmnisNatusError>
                Sed ut perspiciatis unde omnis natus error{" "}
              </SedUtPerspiciatisUndeOmnisNatusError>
            </Title>
            <Navigation
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/fcc999d1-e46e-4671-a8a9-d4ec5c597b60.svg?alt=media&token=d040122d-5edd-4981-b0ad-3741a1b7cd71"
              }
            />
          </Group>
          <Group1>
            <Bg1>
              <Image1
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/cc72b277-dd14-4c77-ac2e-9a850278ce32.png?alt=media&token=7f3b07c2-cf8c-46a1-b59e-f8738ac679d5"
                }
              />
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <Creator1>
                <Image3
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/1eeca442-1dd6-4d63-84c7-bbbd79af69e6.png?alt=media&token=9296082a-2d71-4eea-8e42-1c5deed60978"
                  }
                />
                <Group3>
                  <JaneDoe>Jane Doe</JaneDoe>
                  <Creator>Creator</Creator>
                </Group3>
              </Creator1>
              <Bg2 />
            </Bg1>
            <Bg1>
              <Image1
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/cac48511-9c65-4ae8-9d6a-60cce0373003.png?alt=media&token=0226df4f-1665-4e6f-8a31-0b03464b4c0c"
                }
              />
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <Creator1>
                <Image3
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f80cb2e7-b167-4a5d-8e2a-717a06578f7f.png?alt=media&token=cae8bf5b-9f84-4e7e-aae9-b53ce53d2a85"
                  }
                />
                <Group3>
                  <JaneDoe>John Doe</JaneDoe>
                  <Creator>Creator</Creator>
                </Group3>
              </Creator1>
              <Bg2 />
            </Bg1>
            <Bg1>
              <Image1
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/5f841093-f021-4afe-81bf-27f84cdcae04.png?alt=media&token=d73b154b-2925-475a-9c33-dc789d0507fd"
                }
              />
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <Creator1>
                <Image3
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/90c33bc8-8ea3-4fca-b441-231615e4a80d.png?alt=media&token=5a3409dd-7ada-4a6a-9b3d-e2794909e6b7"
                  }
                />
                <Group3>
                  <JaneDoe>Jane Doe</JaneDoe>
                  <Creator>Creator</Creator>
                </Group3>
              </Creator1>
              <Bg2 />
            </Bg1>
          </Group1>
          <Group2>
            <Bg1>
              <Image1
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/47ebe328-6cdc-46b6-808e-8090fef3a762.png?alt=media&token=a9723ef5-7e6b-46d4-8280-0fc02a944548"
                }
              />
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <Creator1>
                <Image3
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e7af8979-59e2-45b7-a60e-1677e8368349.png?alt=media&token=3e189838-d73d-4d8a-8350-d59f9275666a"
                  }
                />
                <Group3>
                  <JaneDoe>John Doe</JaneDoe>
                  <Creator>Creator</Creator>
                </Group3>
              </Creator1>
              <Bg2 />
            </Bg1>
            <Bg1>
              <Image1
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/3371150f-9d92-45c8-a012-d99416793f72.png?alt=media&token=82e82ae7-4529-428b-af8f-272e626c9a2c"
                }
              />
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <Creator1>
                <Image3
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/dd3f8425-e795-43ea-ae0e-66a852b5dda8.png?alt=media&token=bbedcb57-e2f8-40b9-8895-531d1c93304a"
                  }
                />
                <Group3>
                  <JaneDoe>John Doe</JaneDoe>
                  <Creator>Creator</Creator>
                </Group3>
              </Creator1>
              <Bg2 />
            </Bg1>
            <Bg1>
              <Image1
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/968d3b23-8fb5-4639-b59e-0cb37b609d39.png?alt=media&token=d7d65043-3837-4d9a-96df-0c00a3ad4f86"
                }
              />
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <Creator1>
                <Image3
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/535f1ce7-31e2-4ddd-86d0-4ecfd54d10c0.png?alt=media&token=540b04fb-f417-443c-8c05-0152e9343114"
                  }
                />
                <Group3>
                  <JaneDoe>Jane Doe</JaneDoe>
                  <Creator>Creator</Creator>
                </Group3>
              </Creator1>
              <Bg2 />
            </Bg1>
          </Group2>
        </Trendy>
        <Bg13>
          <Group9>
            <Title1>
              <PoplarCategories>Poplar Categories</PoplarCategories>
              <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem>
                Sed ut perspiciatis unde omnis natus error sit voluptatem
              </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem>
            </Title1>
            <Btn>
              <Bg14
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/57fcd0a9-b721-4383-9b00-190931385286.svg?alt=media&token=5147c002-d1a8-4b54-baf3-be3ead8de3c7"
                }
              />
              <BrowseMore>Browse More</BrowseMore>
            </Btn>
          </Group9>
          <Group10>
            <_14>
              <Image26
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/5b1f52ae-d7c4-4b9c-8107-a77a78d44075.png?alt=media&token=6b251ac3-f92c-4d0b-9d3c-0ffe3cd087ff"
                }
              />
              <Group12>
                <LoremIpsum6>Lorem Ipsum</LoremIpsum6>
                <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                  Sed ut perspiciatis unde omnis natus error sit voluptatem
                </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
              </Group12>
            </_14>
            <_14>
              <Image26
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/a1dc3cb6-4368-4adc-a11b-a43124744a94.png?alt=media&token=70f7b7ca-4303-4191-bb43-9d19a9743816"
                }
              />
              <Group12>
                <LoremIpsum8>Lorem Ipsum</LoremIpsum8>
                <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                  Sed ut perspiciatis unde omnis natus error sit voluptatem
                </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
              </Group12>
            </_14>
            <_14>
              <Image26
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/17ee4eb0-6a44-4553-b39b-35038912efe5.png?alt=media&token=da3e4899-43b5-4ae4-a0f2-6e327ebc9bab"
                }
              />
              <Group12>
                <LoremIpsum10>Lorem Ipsum</LoremIpsum10>
                <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                  Sed ut perspiciatis unde omnis natus error sit voluptatem
                </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
              </Group12>
            </_14>
          </Group10>
          <Group2>
            <_14>
              <Image26
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/60402f62-4d55-4be5-ad76-a3d9eca35d21.png?alt=media&token=8ce85534-5c11-4628-b4b1-9942e8b25da5"
                }
              />
              <Group12>
                <LoremIpsum6>Lorem Ipsum</LoremIpsum6>
                <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                  Sed ut perspiciatis unde omnis natus error sit voluptatem
                </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
              </Group12>
            </_14>
            <_14>
              <Image26
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/3a0082bc-1b1a-47de-9811-5b9732338234.png?alt=media&token=950917c1-613b-418d-b25d-dfbebc02555b"
                }
              />
              <Group12>
                <LoremIpsum6>Lorem Ipsum</LoremIpsum6>
                <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                  Sed ut perspiciatis unde omnis natus error sit voluptatem
                </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
              </Group12>
            </_14>
            <_14>
              <Image26
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/fbe6ec35-b49b-46ac-b606-f5f7e47065f4.png?alt=media&token=d5fb997f-6a7d-41d2-ae84-34811875608c"
                }
              />
              <Group12>
                <LoremIpsum6>Lorem Ipsum</LoremIpsum6>
                <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                  Sed ut perspiciatis unde omnis natus error sit voluptatem
                </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
              </Group12>
            </_14>
          </Group2>
        </Bg13>
        <Newsletters>Newsletters</Newsletters>
      </Bg>
    </NewRootRoot>
  );
};
const Bg1 = styled.div`
  background-color: #ffffff;
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  height: 480px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  border-radius: 20px;
`;
const Image1 = styled.img`
  width: 370px;
  height: 275px;
  margin-bottom: 40px;
  align-self: stretch;
  border-radius: 20px;
`;
const LoremIpsum = styled.div`
  color: #14161b;
  width: 254px;
  height: 13px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  margin-left: 40px;
  margin-bottom: 25px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator1 = styled.div`
  width: 154px;
  margin-left: 40px;
  margin-bottom: 35px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Image3 = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 20px;
`;
const Group3 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 5px;
  padding-bottom: 5px;
  align-items: flex-start;
`;
const JaneDoe = styled.div`
  color: #14161b;
  width: 104px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -0.45px;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator = styled.div`
  color: #959595;
  width: 52px;
  height: 10px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 22px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Bg2 = styled.div`
  background-color: #00dbae;
  border-width: 1px;
  border-color: rgba(99, 69, 237, 0.12);
  border-style: solid;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  width: 370px;
  height: 52px;
  align-self: stretch;
`;
const Group2 = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const _14 = styled.div`
  width: 284px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Image26 = styled.img`
  width: 75px;
  height: 75px;
  border-radius: 40px;
`;
const Group12 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 9px;
  padding-bottom: 9px;
  align-items: flex-start;
`;
const LoremIpsum6 = styled.div`
  color: #14161b;
  width: 166px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1 = styled.div`
  color: #616161;
  width: 189px;
  height: 27px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 18px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const NewRootRoot = styled.div`
  height: 1778px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin: auto;
  min-width: 1920px;
`;
const Bg = styled.div`
  background-color: #fdfdfd;
  height: 1776px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding-top: 1px;
  padding-bottom: 1px;
  padding-left: 395px;
  padding-right: 355px;
`;
const Trendy = styled.div`
  height: 1116px;
  margin-bottom: 35px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Group = styled.div`
  margin-bottom: 60px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: flex-end;
`;
const Title = styled.div`
  height: 66px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const TrendyCollection = styled.div`
  color: #14161b;
  width: 335px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeOmnisNatusError = styled.div`
  color: #616161;
  width: 358px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
const Navigation = styled.img`
  width: 120px;
  height: 55px;
`;
const Group1 = styled.div`
  margin-bottom: 30px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Bg13 = styled.div`
  background-color: #ffffff;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.19);
  height: 431px;
  margin-bottom: 128px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 70px;
  padding-right: 70px;
  border-radius: 30px;
`;
const Group9 = styled.div`
  margin-bottom: 56px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: flex-end;
`;
const Title1 = styled.div`
  height: 60px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const PoplarCategories = styled.div`
  color: #14161b;
  width: 337px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem = styled.div`
  color: #616161;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  align-self: stretch;
`;
const Btn = styled.div`
  width: 189px;
  height: 55px;
  position: relative;
`;
const Bg14 = styled.img`
  width: 189px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const BrowseMore = styled.div`
  color: #ffffff;
  width: 94px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 22px;
  left: 48px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group10 = styled.div`
  margin-bottom: 45px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const LoremIpsum8 = styled.div`
  color: #14161b;
  width: 108px;
  height: 13px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const LoremIpsum10 = styled.div`
  color: #14161b;
  width: 135px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Newsletters = styled.div`
  color: #ffffff;
  width: 337px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  margin-left: 50px;
  align-self: flex-start;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
