import React from "react";
import styled from "styled-components";
export const Categories = ({}) => {
  return (
    <NewRootRoot>
      <Bg>
        <Group>
          <Title>
            <PoplarCategories>Poplar Categories</PoplarCategories>
            <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem>
              Sed ut perspiciatis unde omnis natus error sit voluptatem
            </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem>
          </Title>
          <Btn>
            <Bg1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/0a10c7ab-16b5-422d-b0fe-14c4f1a73aff.svg?alt=media&token=71aec246-3381-4f72-9288-9c822e1f66c0"
              }
            />
            <BrowseMore>Browse More</BrowseMore>
          </Btn>
        </Group>
        <Group1>
          <_1>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2235ccf3-f00a-4df2-88b2-4d7f375d80a1.png?alt=media&token=cc393b24-c6c3-4e0b-8716-1b6562c0d7f2"
              }
            />
            <Group3>
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                Sed ut perspiciatis unde omnis natus error sit voluptatem
              </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
            </Group3>
          </_1>
          <_1>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/599737e1-eecf-4aaf-8614-fb9277251613.png?alt=media&token=19a204af-6860-4c92-85eb-32411b149962"
              }
            />
            <Group3>
              <LoremIpsum2>Lorem Ipsum</LoremIpsum2>
              <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                Sed ut perspiciatis unde omnis natus error sit voluptatem
              </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
            </Group3>
          </_1>
          <_1>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6ccbde8e-8fd4-40e0-9dbb-97732052b5f1.png?alt=media&token=696b2921-c3bc-41d8-9d1d-633f6eeb05d8"
              }
            />
            <Group3>
              <LoremIpsum4>Lorem Ipsum</LoremIpsum4>
              <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                Sed ut perspiciatis unde omnis natus error sit voluptatem
              </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
            </Group3>
          </_1>
        </Group1>
        <Group2>
          <_1>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/db857a60-e21c-4999-a57b-c58a8374b277.png?alt=media&token=6eee9b23-2cdb-48d5-97af-011570f9c2fc"
              }
            />
            <Group3>
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                Sed ut perspiciatis unde omnis natus error sit voluptatem
              </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
            </Group3>
          </_1>
          <_1>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/5525e3ef-4d03-4828-b6b2-e1e2282927a7.png?alt=media&token=f2414dc7-5c64-435f-9be0-7c73b3719eb6"
              }
            />
            <Group3>
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                Sed ut perspiciatis unde omnis natus error sit voluptatem
              </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
            </Group3>
          </_1>
          <_1>
            <Image1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e11d845d-e31c-45e9-a032-864da758b4d5.png?alt=media&token=7e6c65b8-8a5c-4933-937d-88995d1b83f9"
              }
            />
            <Group3>
              <LoremIpsum>Lorem Ipsum</LoremIpsum>
              <SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
                Sed ut perspiciatis unde omnis natus error sit voluptatem
              </SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1>
            </Group3>
          </_1>
        </Group2>
      </Bg>
    </NewRootRoot>
  );
};
const _1 = styled.div`
  width: 284px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Image1 = styled.img`
  width: 75px;
  height: 75px;
  border-radius: 40px;
`;
const Group3 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 9px;
  padding-bottom: 9px;
  align-items: flex-start;
`;
const LoremIpsum = styled.div`
  color: #14161b;
  width: 166px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem1 = styled.div`
  color: #616161;
  width: 189px;
  height: 27px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 18px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const NewRootRoot = styled.div`
  width: 1170px;
  height: 431px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg = styled.div`
  background-color: #ffffff;
  box-shadow: 4px 4px 60px 0px rgba(99, 69, 237, 0.19);
  height: 431px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 70px;
  padding-right: 70px;
  border-radius: 30px;
`;
const Group = styled.div`
  margin-bottom: 56px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: flex-end;
`;
const Title = styled.div`
  height: 60px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const PoplarCategories = styled.div`
  color: #14161b;
  width: 337px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const SedUtPerspiciatisUndeOmnisNatusErrorSitVoluptatem = styled.div`
  color: #616161;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  align-self: stretch;
`;
const Btn = styled.div`
  width: 189px;
  height: 55px;
  position: relative;
`;
const Bg1 = styled.img`
  width: 189px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const BrowseMore = styled.div`
  color: #ffffff;
  width: 94px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 22px;
  left: 48px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group1 = styled.div`
  margin-bottom: 45px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const LoremIpsum2 = styled.div`
  color: #14161b;
  width: 108px;
  height: 13px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const LoremIpsum4 = styled.div`
  color: #14161b;
  width: 135px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 16px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group2 = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
