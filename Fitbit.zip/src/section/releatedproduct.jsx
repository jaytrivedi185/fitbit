import React from "react";
import styled from "styled-components";
export const Releatedproducts = ({}) => {
  return (
    <NewRootRoot>
      <Bg>
        <Group>
          <Title>
            <Group3>
              <Group4>
                <Ellipse5
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2435e81a-178f-4dc5-be66-df626280dd7e.svg?alt=media&token=13af0fc1-10ca-415f-9de9-67cdd44cc8fc"
                  }
                />
                <Ellipse6
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/aa8b5ddf-3bd4-419b-8808-9ed55e108d66.svg?alt=media&token=0772b678-eb49-4ea8-92ba-4f60c0d36834"
                  }
                />
              </Group4>
              <LiveAuctions>Live Auctions</LiveAuctions>
            </Group3>
            <MostPopularGamingDigitalNftMarketPlace>
              Most popular gaming digital nft market place{" "}
            </MostPopularGamingDigitalNftMarketPlace>
          </Title>
          <Navigation
            src={
              "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/b5ad317c-441a-4f53-97ca-270ffacd6e0f.svg?alt=media&token=bc4318b7-5692-455d-8f50-23248643f9d8"
            }
          />
        </Group>
        <Group1>
          <_1>
            <Bg1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/553f1f95-f4b5-41f6-af8c-0133ce530d1f.svg?alt=media&token=d1dbe869-870d-49a2-8844-c2842c34b2b1"
              }
            />
            <Image2>
              <Image1
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f9567244-a095-4a20-9c10-0e5a82146d7b.png?alt=media&token=c49e1d96-faec-4534-aa6d-96f12608950f"
                }
              />
              <Btn>
                <Border
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c836ebfe-d35c-4a69-b3b6-97db4a3498f6.svg?alt=media&token=a84f84ad-e445-4d1b-bc63-90c0dbe1fbd5"
                  }
                />
                <PlaceBid>Place Bid</PlaceBid>
                <_></_>
              </Btn>
            </Image2>
            <Timing>
              <Bg2
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/968a6203-81c9-4449-95d8-41c73f27c02f.svg?alt=media&token=e1aa8e66-320a-498d-abf6-38c0411a61cc"
                }
              />
              <_5293248>05:29:32:48</_5293248>
            </Timing>
            <CurrentBid>Current Bid</CurrentBid>
            <_523ETH>5.23 ETH</_523ETH>
            <_32420>= $32.420</_32420>
            <_3DSpaceRocketWithQRSmokePremium>
              ‘’3D Space Rocket With QR
              <br />
              Smoke Premium’’
            </_3DSpaceRocketWithQRSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/492b0f95-aef6-4487-9467-93f2f876f9f3.png?alt=media&token=4dc87e1f-d5c8-4498-9a43-9cd982be4004"
                }
              />
              <Group5>
                <DanielMBivens>Daniel M. Bivens</DanielMBivens>
                <Creator>Creator</Creator>
              </Group5>
            </Creator1>
            <Tag>
              <Bg3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/45aa49af-235a-48aa-8289-a848ad58dc30.svg?alt=media&token=b6556488-2bbf-41e9-8186-d82cdde72ffe"
                }
              />
              <BSC>BSC</BSC>
            </Tag>
          </_1>
          <_1>
            <Bg1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/48be7dea-ca16-4a1b-873e-563d4441b5b1.svg?alt=media&token=824770ce-ed2a-43c3-a870-25e2ade704cf"
              }
            />
            <Image6
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c15dbf3b-f8c0-4d74-bac0-b949e7dfd4c0.png?alt=media&token=b71d54cf-fc46-42e6-be38-aa32dcde7a4f"
              }
            />
            <Timing>
              <Bg2
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/be45c73d-6ed2-4c25-9b77-7f1353ea152c.svg?alt=media&token=9c07bba6-d34f-4097-b72d-e352eea0bc8e"
                }
              />
              <_5293248>05:29:32:48</_5293248>
            </Timing>
            <CurrentBid>Current Bid</CurrentBid>
            <_523ETH>5.23 ETH</_523ETH>
            <_32420>= $32.420</_32420>
            <_3DSpaceRocketWithQRSmokePremium>
              ‘’3D Space Rocket With QR
              <br />
              Smoke Premium’’
            </_3DSpaceRocketWithQRSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/8ba9d559-08ac-46ae-b3de-bc09722e7f71.png?alt=media&token=e122c799-ae28-483e-892f-b35b08332b8a"
                }
              />
              <Group5>
                <DanielMBivens1>Daniel M. Bivens</DanielMBivens1>
                <Creator>Creator</Creator>
              </Group5>
            </Creator1>
            <Tag>
              <Bg3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e14d2b7e-e2a6-4eb7-a154-d0c968702bed.svg?alt=media&token=0c988818-cfd6-4084-a2e4-ff46d71ae439"
                }
              />
              <BSC>BSC</BSC>
            </Tag>
          </_1>
        </Group1>
        <Group2>
          <_1>
            <Bg1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/ab90e9e1-bb60-413c-b058-efe268e677c8.svg?alt=media&token=8190182c-7b96-4acc-ad44-bea888452cbc"
              }
            />
            <Image6
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/4a7d991b-feae-4666-a7c6-16ee68977df6.png?alt=media&token=a74e3313-0d5d-4598-9631-dc542ca08d39"
              }
            />
            <Timing>
              <Bg2
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/e4653d88-644c-4f69-bad1-a4d566b10c8f.svg?alt=media&token=c5d3737e-ab00-4f0a-a093-1d2875272529"
                }
              />
              <_5293248>05:29:32:48</_5293248>
            </Timing>
            <CurrentBid>Current Bid</CurrentBid>
            <_523ETH>5.23 ETH</_523ETH>
            <_32420>= $32.420</_32420>
            <_3DSpaceRocketWithQRSmokePremium>
              ‘’3D Space Rocket With QR
              <br />
              Smoke Premium’’
            </_3DSpaceRocketWithQRSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/19803bee-e82f-481c-944a-6757d48a4bd1.png?alt=media&token=01c3d183-8847-424b-b7e4-135b20a9fbf8"
                }
              />
              <Group5>
                <DanielMBivens1>Daniel M. Bivens</DanielMBivens1>
                <Creator>Creator</Creator>
              </Group5>
            </Creator1>
            <Tag>
              <Bg3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/02db4129-e6ee-4767-9951-053a7b2e60ff.svg?alt=media&token=88c755f6-150b-4a58-9cd0-a07b023b1f52"
                }
              />
              <BSC>BSC</BSC>
            </Tag>
          </_1>
          <_1>
            <Bg1
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/d2b691f4-22b8-455d-ac18-60e8b726dc69.svg?alt=media&token=f5db2b7f-1fbf-4225-ba2f-bbe5e0929841"
              }
            />
            <Image6
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/b1dbe917-8c78-4993-8419-c134dd2046b2.png?alt=media&token=bbc4f335-dedd-4cf9-ac83-0d52c15bded2"
              }
            />
            <Timing>
              <Bg2
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/b3a4c176-97de-40e6-aadd-cabcdf8ff815.svg?alt=media&token=c6f70ee4-ed49-48d6-9ec9-e32dfd88cefe"
                }
              />
              <_5293248>05:29:32:48</_5293248>
            </Timing>
            <CurrentBid>Current Bid</CurrentBid>
            <_523ETH>5.23 ETH</_523ETH>
            <_32420>= $32.420</_32420>
            <_3DSpaceRocketWithQRSmokePremium>
              ‘’3D Space Rocket With QR
              <br />
              Smoke Premium’’
            </_3DSpaceRocketWithQRSmokePremium>
            <Creator1>
              <Image3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/110ca633-2bf4-4578-8b5b-1b3bd2337779.png?alt=media&token=c93c6f70-5117-4be7-8952-839d49182da3"
                }
              />
              <Group5>
                <DanielMBivens1>Daniel M. Bivens</DanielMBivens1>
                <Creator>Creator</Creator>
              </Group5>
            </Creator1>
            <Tag>
              <Bg3
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/168f0f61-27da-47e8-946c-6094003012df.svg?alt=media&token=573d81ab-58c2-440a-ab16-0f4b145df53a"
                }
              />
              <BSC>BSC</BSC>
            </Tag>
          </_1>
        </Group2>
      </Bg>
    </NewRootRoot>
  );
};
const _1 = styled.div`
  width: 570px;
  height: 319px;
  position: relative;
`;
const Bg1 = styled.img`
  width: 570px;
  height: 319px;
  position: absolute;
  top: 0;
  left: 0;
`;
const Timing = styled.div`
  width: 178px;
  height: 38px;
  position: absolute;
  top: 35px;
  left: 66px;
`;
const Bg2 = styled.img`
  width: 178px;
  height: 38px;
  position: absolute;
  top: 0;
  left: 0;
`;
const _5293248 = styled.div`
  color: #ffffff;
  width: 128px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 600;
  letter-spacing: 3.6px;
  line-height: 30px;
  position: absolute;
  top: 13px;
  left: 25px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const CurrentBid = styled.div`
  color: #7d7d7d;
  width: 74px;
  height: 10px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 223px;
  left: 315px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _523ETH = styled.div`
  color: #14161b;
  width: 72px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 243px;
  left: 315px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _32420 = styled.div`
  color: #7d7d7d;
  width: 65px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 22px;
  position: absolute;
  top: 244px;
  left: 384px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _3DSpaceRocketWithQRSmokePremium = styled.div`
  color: #14161b;
  width: 215px;
  height: 34px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 22px;
  position: absolute;
  top: 104px;
  left: 315px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Creator1 = styled.div`
  width: 154px;
  position: absolute;
  top: 158px;
  left: 315px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const Image3 = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 25px;
`;
const Group5 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 5px;
  padding-bottom: 5px;
  align-items: flex-start;
`;
const Creator = styled.div`
  color: #959595;
  width: 52px;
  height: 10px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 22px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Tag = styled.div`
  width: 47px;
  height: 20px;
  position: absolute;
  top: 64px;
  left: 315px;
`;
const Bg3 = styled.img`
  width: 47px;
  height: 20px;
  position: absolute;
  top: 0;
  left: 0;
`;
const BSC = styled.div`
  color: #ffffff;
  width: 27px;
  height: 9px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 22px;
  position: absolute;
  top: 6px;
  left: 10px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Image6 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 54px;
  left: 45px;
  border-radius: 20px;
`;
const DanielMBivens1 = styled.div`
  color: #6345ed;
  width: 104px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -0.45px;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const NewRootRoot = styled.div`
  width: 1920px;
  height: 1140px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg = styled.div`
  background-color: rgba(99, 69, 237, 0.05);
  height: 940px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  padding-top: 100px;
  padding-bottom: 100px;
  padding-left: 375px;
  padding-right: 374px;
`;
const Group = styled.div`
  margin-bottom: 60px;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 652px;
  align-items: flex-end;
`;
const Title = styled.div`
  height: 66px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-end;
`;
const Group3 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 13px;
`;
const Group4 = styled.div`
  width: 26px;
  height: 29px;
  position: relative;
`;
const Ellipse5 = styled.img`
  width: 26px;
  height: 26px;
  position: absolute;
  top: 2px;
  left: 0;
`;
const Ellipse6 = styled.img`
  width: 12px;
  height: 12px;
  position: absolute;
  top: 9px;
  left: 7px;
`;
const LiveAuctions = styled.div`
  color: #14161b;
  width: 253px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const MostPopularGamingDigitalNftMarketPlace = styled.div`
  color: #616161;
  width: 358px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
const Navigation = styled.img`
  width: 120px;
  height: 55px;
`;
const Group1 = styled.div`
  margin-bottom: 30px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-left: 1px;
  padding-right: 1px;
`;
const Image2 = styled.div`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 54px;
  left: 45px;
`;
const Image1 = styled.img`
  width: 220px;
  height: 230px;
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 20px;
`;
const Btn = styled.div`
  width: 120px;
  height: 40px;
  position: absolute;
  top: 104px;
  left: 50px;
`;
const Border = styled.img`
  width: 120px;
  height: 40px;
  position: absolute;
  top: 0;
  left: 0;
`;
const PlaceBid = styled.div`
  color: #ffffff;
  width: 58px;
  height: 10px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 14px;
  left: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _ = styled.div`
  color: #ffffff;
  width: 16px;
  height: 13px;
  font-size: 16px;
  font-family: Font Awesome 5 Pro;
  line-height: 18px;
  position: absolute;
  top: 13px;
  left: 20px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const DanielMBivens = styled.div`
  color: #00dbae;
  width: 104px;
  height: 11px;
  font-size: 15px;
  font-family: Urbanist;
  font-weight: 700;
  letter-spacing: -0.45px;
  line-height: 22px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group2 = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-left: 1px;
  padding-right: 1px;
`;
