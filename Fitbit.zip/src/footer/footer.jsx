import React from "react";
import styled from "styled-components";
export const Footer = ({}) => {
  return (
    <NewRootRoot>
      <Bg>
        <Group>
          <Group1>
            <Artboard21
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/a00357cf-17b9-4e8c-982e-6ccb9fc7726e.png?alt=media&token=a015fefc-56d4-44f2-88bb-194083232760"
              }
            />
            <Group11>
              <SedUtPerspiciatisUndeOmnisIsteNatusErrorSitVoluptateAccusantiumDoloremqueLaudantiumTotamRemAperiamEaqueIpsaQuaes>
                Sed ut perspiciatis unde omnis iste natus error sit voluptate
                accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
                quaes
              </SedUtPerspiciatisUndeOmnisIsteNatusErrorSitVoluptateAccusantiumDoloremqueLaudantiumTotamRemAperiamEaqueIpsaQuaes>
              <Group3>
                <Fb>
                  <Bg1
                    src={
                      "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c218a102-5ec0-482f-add2-c51bf5e33c91.svg?alt=media&token=08f8a4ba-1867-4c8a-bbae-a71ae05cfd0d"
                    }
                  />
                  <_></_>
                </Fb>
                <Fb>
                  <Bg1
                    src={
                      "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/dcd32ebe-5374-41cf-89b9-aa0d98a8aa50.svg?alt=media&token=03230382-7a58-4b2b-ab17-6f6b47b9ff7e"
                    }
                  />
                  <_1></_1>
                </Fb>
                <Fb>
                  <Bg1
                    src={
                      "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/ce48b791-15fe-4b87-9460-f81332a2db9c.svg?alt=media&token=59fb0caa-75bc-422e-8fe4-de7c48a3a228"
                    }
                  />
                  <_1></_1>
                </Fb>
                <Fb>
                  <Bg1
                    src={
                      "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/2bb60be9-1586-45de-a551-6d186e720fa7.svg?alt=media&token=4f3a76d5-a153-466d-8bf4-2aeca7b46edf"
                    }
                  />
                  <_1></_1>
                </Fb>
              </Group3>
            </Group11>
          </Group1>
          <Group10>
            <Marketplace>Marketplace</Marketplace>
            <LoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsum1>
              Lorem Ipsum
              <br />
              Lorem Ipsum
              <br />
              Lorem Ipsum
              <br />
              Lorem Ipsum
              <br />
              Lorem Ipsum
              <br />
              Lorem Ipsum
            </LoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsum1>
          </Group10>
          <_3>
            <Supports>Supports</Supports>
            <LoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsum>
              Lorem Ipsum
              <br />
              Lorem Ipsum
              <br />
              Lorem Ipsum
              <br />
              Lorem Ipsum
              <br />
              Lorem Ipsum
              <br />
              Lorem Ipsum
            </LoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsum>
          </_3>
          <Group2>
            <NewsPost>News & Post</NewsPost>
            <Group9>
              <Group8>
                <Image1
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/81ac3fc8-95fc-4ccb-bf2d-bdda0939fd18.png?alt=media&token=514f5972-3c4e-4935-a62d-7930b9d35218"
                  }
                />
                <Group4>
                  <LoremIpsumSedUtPerspiciatisUndeAmins>
                    Lorem Ipsum sed ut perspiciatis unde amins
                  </LoremIpsumSedUtPerspiciatisUndeAmins>
                  <Date1>
                    <Vector
                      src={
                        "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/c3e5d5e9-766b-42e9-bb42-7d904bbbd98d.svg?alt=media&token=140b5a00-3279-4c13-b125-fe8e3ad02785"
                      }
                    />
                    <_25Jan2022>25 Jan 2022</_25Jan2022>
                  </Date1>
                </Group4>
              </Group8>
              <_2>
                <Image1
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/6d8eea31-9178-4214-b158-6852e10ac54a.png?alt=media&token=35b4b97b-a111-4f01-8339-692158cb420c"
                  }
                />
                <Group4>
                  <LoremIpsumSedUtPerspiciatisUndeAmins1>
                    Lorem Ipsum sed ut perspiciatis unde amins
                  </LoremIpsumSedUtPerspiciatisUndeAmins1>
                  <Date1>
                    <Vector
                      src={
                        "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/99dcf71d-2b6e-48f8-9fb9-00f0045c64b2.svg?alt=media&token=375ca0ab-9f0c-4328-af23-7fdbd3ad63e0"
                      }
                    />
                    <_25Jan2022>25 Jan 2022</_25Jan2022>
                  </Date1>
                </Group4>
              </_2>
            </Group9>
          </Group2>
        </Group>
        <Bg5 />
        <_CopyrightFitbit2022AllRightReserved>
          © Copyright Fitbit 2022 -All Right Reserved{" "}
        </_CopyrightFitbit2022AllRightReserved>
      </Bg>
    </NewRootRoot>
  );
};
const Fb = styled.div`
  width: 30px;
  height: 30px;
  position: relative;
`;
const Bg1 = styled.img`
  width: 30px;
  height: 30px;
  position: absolute;
  top: 0;
  left: 0;
`;
const _1 = styled.div`
  color: #ffffff;
  width: 13px;
  height: 10px;
  font-size: 13px;
  font-family: Font Awesome 5 Brands;
  font-weight: 400;
  line-height: 25px;
  position: absolute;
  top: 10px;
  left: 8px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Image1 = styled.img`
  width: 70px;
  height: 70px;
  border-radius: 7px;
`;
const Group4 = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 3px;
  padding-bottom: 3px;
  align-items: flex-start;
`;
const Date1 = styled.div`
  width: 97.75px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`;
const Vector = styled.img`
  width: 13.5px;
  height: 13.5px;
  align-self: stretch;
`;
const _25Jan2022 = styled.div`
  color: rgba(255, 255, 255, 0.5);
  width: 75px;
  height: 10px;
  font-size: 13px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 28px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const NewRootRoot = styled.div`
  height: 549px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin: auto;
  min-width: 1920px;
`;
const Bg = styled.div`
  background-color: #14141f;
  height: 489px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding-top: 30px;
  padding-bottom: 30px;
  padding-left: 357px;
  padding-right: 375px;
  align-items: flex-end;
`;
const Group = styled.div`
  align-self: stretch;
  margin-bottom: 80px;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: flex-end;
`;
const Group1 = styled.div`
  align-self: stretch;
  width: 250px;
  margin-right: 126px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  gap: 35px;
  align-items: flex-start;
`;
const Artboard21 = styled.img`
  width: 197px;
  height: 56px;
`;
const Group11 = styled.div`
  height: 139px;
  align-self: flex-end;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;
const SedUtPerspiciatisUndeOmnisIsteNatusErrorSitVoluptateAccusantiumDoloremqueLaudantiumTotamRemAperiamEaqueIpsaQuaes = styled.div`
  color: rgba(255, 255, 255, 0.8);
  width: 232px;
  height: 80px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 25px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group3 = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 10px;
`;
const _ = styled.div`
  color: #ffffff;
  width: 9px;
  height: 13px;
  font-size: 13px;
  font-family: Font Awesome 5 Brands;
  font-weight: 400;
  line-height: 25px;
  position: absolute;
  top: 9px;
  left: 10px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group10 = styled.div`
  height: 221px;
  margin-right: 130px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;
const Marketplace = styled.div`
  color: #ffffff;
  width: 103px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const LoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsum1 = styled.div`
  color: rgba(255, 255, 255, 0.8);
  width: 103px;
  height: 174px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 33px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _3 = styled.div`
  height: 221px;
  margin-right: 130px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const Supports = styled.div`
  color: #ffffff;
  width: 100.52px;
  height: 11.67px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const LoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsumLoremIpsum = styled.div`
  color: rgba(255, 255, 255, 0.8);
  width: 130px;
  height: 175px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 33px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group2 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  gap: 35px;
  padding-top: 16px;
  padding-bottom: 14px;
  align-items: flex-start;
`;
const NewsPost = styled.div`
  color: #ffffff;
  width: 100px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Group9 = styled.div`
  height: 160px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const Group8 = styled.div`
  width: 310px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const LoremIpsumSedUtPerspiciatisUndeAmins = styled.div`
  color: #ffffff;
  width: 215px;
  height: 39px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 23px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _2 = styled.div`
  width: 317px;
  align-self: stretch;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const LoremIpsumSedUtPerspiciatisUndeAmins1 = styled.div`
  color: #ffffff;
  width: 222px;
  height: 35px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 600;
  line-height: 23px;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Bg5 = styled.div`
  background-color: rgba(255, 255, 255, 0.1);
  width: 1170px;
  height: 1px;
  margin-bottom: 27px;
`;
const _CopyrightFitbit2022AllRightReserved = styled.div`
  color: rgba(255, 255, 255, 0.6);
  width: 274px;
  height: 13px;
  font-size: 14px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 25px;
  margin-right: 424px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
