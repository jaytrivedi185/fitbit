import React from "react";
import styled from "styled-components";
export const newsletter = ({}) => {
  return (
    <NewRootRoot>
      <Bg>
        <Title>
          <Newsletters>Newsletters</Newsletters>
          <MostPopularGamingDigitalNftMarketPlace>
            Most popular gaming digital nft market place{" "}
          </MostPopularGamingDigitalNftMarketPlace>
        </Title>
        <Bg1>
          <EnterEmailAddress>Enter Email Address</EnterEmailAddress>
          <Btn2>
            <Bg2
              src={
                "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/f22f6811-c21f-42a6-9ada-15ebbf51525d.svg?alt=media&token=b1dc742a-57f9-4e6d-9b05-f98e48dc1675"
              }
            />
            <BrowseMore>Browse More</BrowseMore>
            <_></_>
            <Btn1>
              <Bg2
                src={
                  "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/ed054060-f479-416b-9e94-75d14de505c5.svg?alt=media&token=fbbae0f8-434a-4657-b0ba-3ae759277c28"
                }
              />
              <BrowseMore>Browse More</BrowseMore>
              <_></_>
              <Btn1>
                <Bg4
                  src={
                    "https://firebasestorage.googleapis.com/v0/b/rendition-prod.appspot.com/o/cae51608-64f2-4184-ab1c-c22e544099e2.svg?alt=media&token=567a2bbe-79c4-4719-9f95-f83e2f7979f2"
                  }
                />
                <BrowseMore2>Browse More</BrowseMore2>
                <_2></_2>
              </Btn1>
            </Btn1>
          </Btn2>
        </Bg1>
      </Bg>
    </NewRootRoot>
  );
};
const Bg2 = styled.img`
  width: 189px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 1px;
`;
const BrowseMore = styled.div`
  color: #ffffff;
  width: 94px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 61px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _ = styled.div`
  color: #ffffff;
  width: 16px;
  height: 13px;
  font-size: 16px;
  font-family: Font Awesome 5 Pro;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 36px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Btn1 = styled.div`
  width: 191px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const NewRootRoot = styled.div`
  width: 1170px;
  height: 195px;
  transform-origin: 0px 0px;
  transform: rotate(NaNdeg);
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Bg = styled.div`
  background-color: #02a886;
  width: 1030px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-left: 70px;
  padding-right: 70px;
  padding-top: 60px;
  padding-bottom: 60px;
  align-items: center;
  border-radius: 30px;
`;
const Title = styled.div`
  height: 66px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
`;
const Newsletters = styled.div`
  color: #ffffff;
  width: 337px;
  height: 29px;
  font-size: 42px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 42px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const MostPopularGamingDigitalNftMarketPlace = styled.div`
  color: #ffffff;
  width: 358px;
  height: 12px;
  font-size: 18px;
  font-family: Urbanist;
  font-weight: 400;
  line-height: 0;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
  white-space: pre-wrap;
`;
const Bg1 = styled.div`
  background-color: #ffffff;
  width: 559px;
  align-self: stretch;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  gap: 195px;
  padding-left: 9px;
  padding-right: 9px;
  padding-top: 10px;
  padding-bottom: 10px;
  align-items: center;
  border-radius: 187px;
`;
const EnterEmailAddress = styled.div`
  color: #616161;
  width: 142px;
  height: 11px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 500;
  line-height: 18px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const Btn2 = styled.div`
  width: 191px;
  height: 55px;
  align-self: stretch;
  position: relative;
`;
const Bg4 = styled.img`
  width: 191px;
  height: 55px;
  position: absolute;
  top: 0;
  left: 0;
`;
const BrowseMore2 = styled.div`
  color: #ffffff;
  width: 96px;
  height: 12px;
  font-size: 16px;
  font-family: Urbanist;
  font-weight: 700;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 60px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
const _2 = styled.div`
  color: #ffffff;
  width: 16px;
  height: 13px;
  font-size: 16px;
  font-family: Font Awesome 5 Pro;
  line-height: 18px;
  position: absolute;
  top: 21px;
  left: 35px;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: center;
`;
